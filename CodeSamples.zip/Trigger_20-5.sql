/* 20-5 */
-- Show the DML triggers in the current database 
USE AdventureWorks2014;
GO

SELECT  OBJECT_NAME(parent_id) AS ParentObjName,
        name AS TriggerName,
        is_instead_of_trigger,
        is_disabled
FROM    sys.triggers t
WHERE   parent_class_desc = 'OBJECT_OR_COLUMN'
ORDER BY OBJECT_NAME(parent_id),Name ;


-- Displays the trigger SQL definition --(if the trigger is not encrypted) 
USE AdventureWorks2014;
GO

SELECT  o.name
        , (SELECT definition AS [processing-instruction(definition)]
            FROM sys.sql_modules
            WHERE object_id = m.object_id
            FOR XML PATH(''), TYPE
      ) AS TrigDefinition
FROM    sys.sql_modules m
        INNER JOIN sys.objects o
            ON m.object_id = o.object_id
WHERE   o.type = 'TR'
        AND o.name = 'trg_id_ProductInventoryAudit';
