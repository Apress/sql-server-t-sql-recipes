/* 18-6 */
Use AdventureWorks2014;
GO
CREATE FUNCTION dbo.udf_GET_AssignedEquipment (@Title nvarchar(50), @HireDate datetime, @SalariedFlag bit) 
RETURNS nvarchar(50) 
AS 
BEGIN
DECLARE @EquipmentType nvarchar(50)
IF @Title LIKE 'Chief%' OR
      @Title LIKE 'Vice%' OR
      @Title = 'Database Administrator' 
BEGIN
      SET @EquipmentType = 'PC Build A' ;
END
IF @EquipmentType IS NULL AND @SalariedFlag = 1 
BEGIN
      SET @EquipmentType = 'PC Build B' ;
END
IF @EquipmentType IS NULL AND @HireDate < '1/1/2002' 
BEGIN
      SET @EquipmentType = 'PC Build C' ;
END
IF @EquipmentType IS NULL 
BEGIN
      SET @EquipmentType = 'PC Build D' ;
END
RETURN @EquipmentType ;
END
GO


/* test it */
Use AdventureWorks2014;
GO
SELECT PC_Build = dbo.udf_GET_AssignedEquipment(JobTitle, HireDate, SalariedFlag) 
      , Employee_Count = COUNT(*)  
FROM HumanResources.Employee 
GROUP BY dbo.udf_GET_AssignedEquipment(JobTitle, HireDate, SalariedFlag) 
ORDER BY dbo.udf_GET_AssignedEquipment(JobTitle, HireDate, SalariedFlag);

Use AdventureWorks2014;
GO
SELECT JobTitle,BusinessEntityID
      ,PC_Build = dbo.udf_GET_AssignedEquipment(JobTitle, HireDate, SalariedFlag)  
FROM HumanResources.Employee 
WHERE dbo.udf_GET_AssignedEquipment(JobTitle, HireDate, SalariedFlag) 
      IN ('PC Build A', 'PC Build B');
