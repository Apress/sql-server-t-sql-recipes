/* 28-1 */
USE master;
GO

DECLARE @BackupDate CHAR(8) = CONVERT(VARCHAR, GETDATE(), 112)
	, @BackupPath VARCHAR(50);
	
SET @BackupPath = 'C:\Apress\TestDB_' + @BackupDate + '.BAK';

BACKUP DATABASE TestDB
TO DISK = @BackupPath;
GO
-- Time passes, we make another backup to the same device
USE master;
GO

DECLARE @BackupDate CHAR(8) = CONVERT(VARCHAR, GETDATE(), 112)
	, @BackupPath VARCHAR(50);
	
SET @BackupPath = 'C:\Apress\TestDB_' + @BackupDate + '.BAK';

BACKUP DATABASE TestDB
TO DISK = @BackupPath;
GO

/* restore the database */

USE master;
GO

DECLARE @DeviceName VARCHAR(50);

SELECT @DeviceName = b.physical_device_name
	FROM msdb.dbo.backupset a
		INNER JOIN msdb.dbo.backupmediafamily b
			ON a.media_set_id = b.media_set_id
	WHERE a.database_name = 'TestDB'
		AND a.type = 'D'
		AND CONVERT(VARCHAR, a.backup_start_date, 112) = CONVERT(VARCHAR, GETDATE(), 112)
		AND a.position = 2;

RESTORE DATABASE TestDB
FROM DISK = @DeviceName
WITH FILE = 2, REPLACE;
GO

/* restore additional db */
USE master;
GO

Declare @DeviceName Varchar(50);

Select @DeviceName = b.physical_device_name
    From msdb.dbo.backupset a
        INNER JOIN msdb.dbo.backupmediafamily b
        ON a.media_set_id = b.media_set_id
    Where a.database_name = 'TestDB'
        And a.type = 'D'
        And Convert(Varchar,a.backup_start_date,112) = Convert(Varchar,GetDate(),112);
RESTORE DATABASE TrainingDB
FROM DISK = @DeviceName
WITH FILE = 2,
MOVE 'TestDB' TO 'C:\Apress\TrainingDB.mdf',
MOVE 'TestDB_log' TO 'C:\Apress\TrainingDB_log.LDF';
GO

/* striped backup */

USE master;
GO
/* The path for each file should be changed to a path matching one
That exists on your system. */
BACKUP DATABASE TestDB
TO DISK = 'C:\Apress\TestDB_Stripe1.bak'
    , DISK = 'C:\Apress\StripedBacks\TestDB_Stripe2.bak'
    , DISK = 'C:\Apress\StripedBacks\TestDB_Stripe3.bak'
    WITH NOFORMAT, NOINIT,  
NAME = N'TestDB-Stripe Database Backup', 
SKIP, STATS = 20;
GO

/* recover from striped backup */
USE master;
GO
/* You should use the same file path for each file as specified
in the backup statement. */
RESTORE DATABASE TestDB
FROM DISK = 'C:\Apress\TestDB_Stripe1.bak'
    , DISK = 'C:\Apress\StripedBacks\TestDB_Stripe2.bak'
    , DISK = 'C:\Apress\StripedBacks\TestDB_Stripe3.bak' 
    WITH FILE = 1, REPLACE;
GO
