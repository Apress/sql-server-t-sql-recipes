/* 24-6 */
USE AdventureWorks2014;
GO
CREATE STATISTICS Stats_Customer_AccountNumber 
ON Sales.Customer (AccountNumber) WITH FULLSCAN;
