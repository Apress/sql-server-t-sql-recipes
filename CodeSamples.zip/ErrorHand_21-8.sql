/* 21-8 */
USE master
GO

IF EXISTS ( SELECT 1/0 FROM sys.messages WHERE message_id = 50001)
BEGIN
  EXEC sp_dropmessage 50001;
END
GO 

/* Confirm the error has been deleted */
SELECT message_id,	
	 text
FROM sys.messages
WHERE message_id = 50001;
GO

/* Now try to use that error */
RAISERROR(50001,16,1);
GO 
