/* 29 - 1 */
/* create login from local windows or domain user */
USE master;
GO
CREATE LOGIN [PetitMot\JeanLouis]
FROM WINDOWS
WITH DEFAULT_DATABASE = AdventureWorks2014,
DEFAULT_LANGUAGE = English;
GO

/* create from windows or domain group */
USE master;
GO
CREATE LOGIN [PetitMot\Contenu]
FROM WINDOWS
WITH DEFAULT_DATABASE= AdventureWorks2014;
GO
