/* 12-4 */
USE AdventureWorks2014;
BEGIN TRAN
SELECT ProductID, ModifiedDate 
FROM Production.ProductDocument WITH (TABLOCKX);

/*
In a second query editor window, the following query is executed:
*/
SELECT sessionid = request_session_id ,
ResType = resource_type ,
ResDBID = resource_database_id ,
ObjectName = OBJECT_NAME(resource_associated_entity_id, resource_database_id) ,
RMode = request_mode ,
RStatus = request_status  
FROM sys.dm_tran_locks 
WHERE resource_type IN ('DATABASE', 'OBJECT');
GO


/* in the original query window */
ROLLBACK TRAN;