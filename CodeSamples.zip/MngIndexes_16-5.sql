/* 15-4 */
USE AdventureWorks2014;
GO
ALTER TABLE HumanResources.TerminationReason
ADD ViolationSeverityLevel smallint;
GO
CREATE NONCLUSTERED INDEX NI_TerminationReason_ViolationSeverityLevel 
  ON HumanResources.TerminationReason (ViolationSeverityLevel DESC);
