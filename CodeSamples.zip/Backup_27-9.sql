/* 27-9 */
CREATE DATABASE BackupFiles
 ON  PRIMARY 
( NAME = N'BackupFiles', FILENAME = N'C:\Apress\BackupFiles.mdf' , SIZE = 4096KB , FILEGROWTH = 1024KB ), 
 FILEGROUP [Current] 
( NAME = N'CurrentData', FILENAME = 'C:\Apress\CurrentData.ndf' , SIZE = 4096KB , FILEGROWTH = 1024KB ), 
 FILEGROUP [Historic] 
( NAME = N'HistoricData', FILENAME = 'C:\Apress\HistoricData.ndf' , SIZE = 4096KB , FILEGROWTH = 1024KB )
 LOG ON 
( NAME = N'BackupFiles_log', FILENAME = 'C:\Apress\BackupFiles_log.ldf' , SIZE = 1024KB , FILEGROWTH = 512KB);
GO
ALTER DATABASE [BackupFiles] SET RECOVERY FULL; 
GO

/* Backup a File */
USE master;
GO

BACKUP DATABASE BackupFiles
FILE = 'HistoricData'
TO DISK =  'C:\Apress\Historic.bak';
GO

/* backup a FG */
USE master;
GO

BACKUP DATABASE BackupFiles
FILEGROUP = 'Historic'
TO DISK =  'C:\Apress\HistoricFG.bak';
GO
