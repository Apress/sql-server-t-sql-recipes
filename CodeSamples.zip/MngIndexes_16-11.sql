/* 15-10 */
USE AdventureWorks2014;
GO
CREATE NONCLUSTERED INDEX NI_Address_AddressLine1 
  ON Person.Address (AddressLine1) 
  WITH (MAXDOP = 4);
