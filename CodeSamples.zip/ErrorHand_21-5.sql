/* 21-5 */
USE tempdb;
GO

BEGIN TRY
  SELECT 1/0 --This will raise a divide by zero error if not handled
	BEGIN TRY
	 	PRINT 'Inner Try'
	END TRY
    	BEGIN CATCH
		PRINT CONVERT(CHAR(5), ERROR_NUMBER()) + 'Inner Catch' 
   	END CATCH
END TRY
BEGIN CATCH 
  PRINT CONVERT(CHAR(5), ERROR_NUMBER()) + 'Outer Catch' 
END CATCH;	
GO

/* reversal of inner and outer */
USE tempdb;
GO

BEGIN TRY
  PRINT 'Outer Try'
    BEGIN TRY
	 	SELECT 1/0 --This will raise a divide by zero error if not handled
    END TRY
    BEGIN CATCH
		PRINT CONVERT(CHAR(5), ERROR_NUMBER()) + 'Inner Catch' 
    END CATCH
END TRY
BEGIN CATCH 
  PRINT CONVERT(CHAR(5), ERROR_NUMBER()) + 'Outer Catch' 
END CATCH;	
GO

/* more complex */
USE tempdb;
GO

BEGIN TRY
  PRINT 'Outer Try'
    BEGIN TRY
	 	PRINT ERROR_NUMBER() + ' Inner try'
    END TRY
    BEGIN CATCH
        IF ERROR_NUMBER() = 8134
		   PRINT CONVERT(CHAR(5), ERROR_NUMBER()) + ' Inner Catch Divide by zero'
        ELSE 
            BEGIN
            PRINT CONVERT(CHAR(6), ERROR_NUMBER()) + ' '
			 + ERROR_MESSAGE() +
              CONVERT(CHAR(2), ERROR_SEVERITY()) + ' ' +
              CONVERT(CHAR(2), ERROR_STATE()) + ' INITIAL Catch';
            END
    END CATCH;
END TRY
BEGIN CATCH
    IF ERROR_NUMBER() = 8134
        PRINT CONVERT(CHAR(5), ERROR_NUMBER()) + ' Outer Catch Divide by zero' 
    ELSE 
        BEGIN
        PRINT CONVERT(CHAR(6), ERROR_NUMBER()) + ' ' + ERROR_MESSAGE() +
              CONVERT(CHAR(2), ERROR_SEVERITY()) + ' ' + 
              CONVERT(CHAR(2), ERROR_STATE()) + ' OUTER Catch';
        THROW
        END
END CATCH;

/* one more tweak */
USE tempdb;
GO

BEGIN TRY
  PRINT 'Outer Try'
    BEGIN TRY
	 	PRINT ERROR_NUMBER() + ' Inner try'
    END TRY
    BEGIN CATCH
        IF ERROR_NUMBER() = 8134
		   PRINT CONVERT(CHAR(5), ERROR_NUMBER()) + ' Inner Catch Divide by zero'
        ELSE 
            BEGIN
            PRINT CONVERT(CHAR(6), ERROR_NUMBER()) + ' '
			 + ERROR_MESSAGE() +
              CONVERT(CHAR(2), ERROR_SEVERITY()) + ' ' +
              CONVERT(CHAR(2), ERROR_STATE()) + ' INITIAL Catch';
           THROW --This THROW is added in the initial CATCH
           END
    END CATCH;
END TRY
BEGIN CATCH
    IF ERROR_NUMBER() = 8134
        PRINT CONVERT(CHAR(5), ERROR_NUMBER()) + ' Outer Catch Divide by zero' 
    ELSE 
        BEGIN
        PRINT CONVERT(CHAR(6), ERROR_NUMBER()) + ' ' + ERROR_MESSAGE() +
              CONVERT(CHAR(2), ERROR_SEVERITY()) + ' ' + 
              CONVERT(CHAR(2), ERROR_STATE()) + ' OUTER Catch';
        THROW
        END
END CATCH;