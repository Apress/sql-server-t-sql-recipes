/* 27-12 */
USE msdb;
GO
SELECT bs.database_name,
	   bs.backup_start_date,
	   CASE bs.type
	     WHEN 'D' THEN 'Full Database'
	     WHEN 'I' THEN 'Differential Database' 
	     WHEN 'L' THEN 'Log' 
	     WHEN 'F' THEN 'File or Filegroup' 
	     WHEN 'G' THEN 'Differential File'
	     WHEN 'P' THEN 'Partial'
	     WHEN 'Q' THEN 'Differential Partial'
	     ELSE 'Unknown'
	   END AS BackupType,
	   bmf.physical_device_name,
	   bs.backup_size/1024/1024 as BackSizeMB
FROM dbo.backupset bs 
INNER JOIN dbo.backupmediafamily bmf
ON bs.media_set_id = bmf.media_set_id
ORDER BY bs.database_name,bs.backup_start_date DESC;
GO
