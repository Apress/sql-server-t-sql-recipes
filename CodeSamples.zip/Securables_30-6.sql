/* 30-6 */
USE TestDB;
GO
CREATE SCHEMA Publishers AUTHORIZATION db_owner;
GO

/* Create an object in this new schema */

USE TestDB;
GO
CREATE TABLE Publishers.ISBN (ISBN char(13) NOT NULL PRIMARY KEY, CreateDT datetime NOT NULL DEFAULT GETDATE());
GO

/* creaet a login */
USE master
GO
CREATE LOGIN Rossignol
WITH PASSWORD=N'testl23',
DEFAULT_DATABASE=TestDB,
CHECK_EXPIRATION=OFF,
CHECK_POLICY=OFF;
GO

/* create a user in the database */

USE TestDB;
GO
CREATE USER Rossignol FOR LOGIN Rossignol;
GO

/* change user default schema */
USE TestDB;
GO
ALTER USER Rossignol WITH DEFAULT_SCHEMA=Publishers;
GO

/* transfer schema ownership of an object */
USE TestDB;
GO
ALTER SCHEMA dbo TRANSFER Publishers.ISBN;
GO
DROP SCHEMA Publishers;
GO
