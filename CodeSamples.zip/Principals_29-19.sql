/* 29-19 */
USE TestDB
GO
If not exists (select name from sys.database_principals
        where name = 'Gargouille')
Begin
CREATE LOGIN Gargouille
WITH PASSWORD = 'BigTr3e',
DEFAULT_DATABASE = TestDB;
CREATE USER Gargouille;
END
GO
ALTER ROLE db_datawriter
    ADD MEMBER [GARGOUILLE];
ALTER ROLE db_datareader
    ADD MEMBER [GARGOUILLE];
GO


/* drop the user from the role */
USE TestDB;
GO
ALTER ROLE db_datawriter
    DROP MEMBER [GARGOUILLE];
GO
