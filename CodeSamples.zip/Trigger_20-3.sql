/* 20-3 */
USE AdventureWorks2014;
GO

ALTER TRIGGER Production.trg_id_ProductInventoryAudit ON Production.ProductInventory
       AFTER INSERT, DELETE
AS
       SET NOCOUNT ON ;
       IF EXISTS ( SELECT   Shelf
                   FROM     inserted
                   WHERE    Shelf = 'A' ) 
          BEGIN
                PRINT 'Shelf ''A'' is closed for new inventory.' ;
                ROLLBACK ;
          END
-- Inserted rows
       INSERT INTO Production.ProductInventoryAudit
                (ProductID,
                 LocationID,
                 Shelf,
                 Bin,
                 Quantity,
                 rowguid,
                 ModifiedDate,
                 InsertOrDelete)
                SELECT DISTINCT
                        i.ProductID,
                        i.LocationID,
                        i.Shelf,
                        i.Bin,
                        i.Quantity,
                        i.rowguid,
                        GETDATE(),
                        'I'
                FROM    inserted i ;
-- Deleted rows
       INSERT INTO Production.ProductInventoryAudit
                (ProductID,
                 LocationID,
                 Shelf,
                 Bin,
                 Quantity,
                 rowguid,
                 ModifiedDate,
                 InsertOrDelete)
                SELECT  d.ProductID,
                        d.LocationID,
                        d.Shelf,
                        d.Bin,
                        d.Quantity,
                        d.rowguid,
                        GETDATE(),
                        'D'
                FROM    deleted d ;
       IF EXISTS ( SELECT   Quantity
                   FROM     deleted
                   WHERE    Quantity > 0 ) 
          BEGIN
                PRINT 'You cannot remove positive quantity rows!' ;
                ROLLBACK ;
          END
GO

/* Attempt an insert of a row using Shelf A */

INSERT INTO Production.ProductInventory
        (ProductID,
         LocationID,
         Shelf,
         Bin,
         Quantity)
VALUES  (316,
         6,
         'A',
         4,
         22) ;

/* Try some deletes */
BEGIN TRANSACTION ;
-- Deleting a row with a zero quantity 
DELETE  
FROM Production.ProductInventory
WHERE   ProductID = 853
        AND LocationID = 7 ;
-- Deleting a row with a non-zero quantity 
DELETE  
FROM Production.ProductInventory
WHERE   ProductID = 999
        AND LocationID = 60 ;
COMMIT TRANSACTION ;
