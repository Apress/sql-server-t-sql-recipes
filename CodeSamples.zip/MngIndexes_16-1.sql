/* 15-1 */
/* Create a New Table without Indexes */
USE AdventureWorks2014;
GO
IF NOT EXISTS (Select 1/0 from sys.objects where name = 'TerminationReason' and SCHEMA_NAME(schema_id) = 'HumanResources')
BEGIN
CREATE TABLE HumanResources.TerminationReason(
  TerminationReasonID smallint IDENTITY(1,1) NOT NULL, 
  TerminationReason varchar(50) NOT NULL, 
  DepartmentID smallint NOT NULL, 
  CONSTRAINT FK_TerminationReason_DepartmentID FOREIGN KEY (DepartmentID) 
REFERENCES HumanResources.Department(DepartmentID) 
	);
END

/* Create a Primary Key and Clustered Index */
USE AdventureWorks2014;
GO
ALTER TABLE HumanResources.TerminationReason
ADD CONSTRAINT PK_TerminationReason PRIMARY KEY CLUSTERED (TerminationReasonID);

/* create a nonclustered index on the Departments column. */
USE AdventureWorks2014;
GO
CREATE NONCLUSTERED INDEX NCI_TerminationReason_DepartmentID ON HumanResources.TerminationReason (DepartmentID);
