/* 12-3 */
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE;
GO
USE AdventureWorks2014;
GO
BEGIN TRAN
SELECT *
FROM  HumanResources.Department
INSERT INTO HumanResources.Department (Name, GroupName) 
    VALUES ('Test', 'QA');


/*
In a new SQL Server Management Studio query window
*/

SELECT session_id, transaction_id, is_user_transaction, is_local 
FROM sys.dm_tran_session_transactions 
WHERE is_user_transaction = 1;
GO

SELECT s.text
FROM sys.dm_exec_connections c
CROSS APPLY sys.dm_exec_sql_text(c.most_recent_sql_handle) s
WHERE c.most_recent_session_id = 57;--use the session_id returned by the previous query
GO



SELECT transaction_begin_time
,tran_type = CASE transaction_type
    WHEN 1 THEN 'Read/write transaction'
    WHEN 2 THEN 'Read-only transaction'
    WHEN 3 THEN 'System transaction'
    WHEN 4 THEN 'Distributed transaction' 
    END 
,tran_state = CASE transaction_state
    WHEN 0 THEN 'not been completely initialized yet'
    WHEN 1 THEN 'initialized but has not started'
    WHEN 2 THEN 'active'
    WHEN 3 THEN 'ended (read-only transaction)'
    WHEN 4 THEN 'commit initiated for distributed transaction'
    WHEN 5 THEN 'transaction prepared and waiting resolution'
    WHEN 6 THEN 'committed'
    WHEN 7 THEN 'being rolled back'
    WHEN 8 THEN 'been rolled back' 
    END  
FROM sys.dm_tran_active_transactions 
WHERE transaction_id = 12969598; -- change this value to the transaction_id returned in the first 
--query of this recipe
GO