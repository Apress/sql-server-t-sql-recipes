/* 29-18 */
USE AdventureWorks2014;
GO
EXECUTE sp_helpdbfixedrole;
GO

USE TestDB;
GO
EXECUTE sp_helprolemember;
GO
