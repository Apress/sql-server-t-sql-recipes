/* 22-6 */
USE AdventureWorks2014;
GO
SELECT BusinessEntityID
FROM Purchasing.vVendorWithContacts
WHERE EmailAddress = 'cheryl1@adventure-works.com';
GO
SELECT BusinessEntityID
FROM Purchasing.vVendorWithContacts
WHERE EmailAddress = 'stuart2@adventure-works.com';
GO
SELECT BusinessEntityID
FROM Purchasing.vVendorWithContacts
WHERE EmailAddress = 'suzanne0@adventure-works.com';
GO

USE AdventureWorks2014;
GO
SELECT  t.text,
st.total_logical_reads 
FROM sys.dm_exec_query_stats st 
CROSS APPLY sys.dm_exec_sql_text(st.sql_handle) t 
WHERE t.text LIKE '%Purchasing.vVendorWithContacts%';


/* aggregate the adhocs */

USE AdventureWorks2014;
GO
SELECT 
MAX(t.text) as query_text,
COUNT(t.text) query_count,
SUM(st.total_logical_reads) total_logical_reads 
FROM sys.dm_exec_query_stats st 
CROSS APPLY sys.dm_exec_sql_text(st.sql_handle) t 
WHERE text LIKE '%Purchasing.vVendorWithContacts%'
GROUP BY st.query_hash;
