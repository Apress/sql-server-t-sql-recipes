/* 20-8 */

USE AdventureWorks2014;
GO

-- Show the DML triggers in the current database
SELECT  name AS TriggerName,
        is_disabled
FROM    sys.triggers
WHERE   parent_class_desc = 'DATABASE'
ORDER BY OBJECT_NAME(parent_id),
        Name ;

--server scoped triggers
SELECT  name AS TriggerName,
        s.type_desc AS TriggerType,
        is_disabled,
        e.type_desc AS FiringEvents
FROM    sys.server_triggers s
        INNER JOIN sys.server_trigger_events e
            ON s.object_id = e.object_id ;

-- database-scoped DDL triggers definitions
USE AdventureWorks2014;
GO

SELECT  t.name AS TriggerName
        , (SELECT definition AS [processing-instruction(definition)]
            FROM sys.sql_modules
            WHERE object_id = t.object_id
            FOR XML PATH(''), TYPE
      ) AS TrigDefinition
FROM    sys.triggers AS t
WHERE   t.parent_class_desc = 'DATABASE' ;

--server scoped DDL trigger definitions
USE master;
GO
SELECT  t.name
        , (SELECT definition AS [processing-instruction(definition)]
            FROM sys.server_sql_modules
            WHERE object_id = t.object_id
            FOR XML PATH(''), TYPE
      ) AS TrigDefinition
FROM   sys.server_triggers t;
