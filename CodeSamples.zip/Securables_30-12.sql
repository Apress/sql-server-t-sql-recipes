/* 30-12 */
USE master;
GO
CREATE CREDENTIAL AccountingGroup
WITH IDENTITY = N'PETITMOT\AccountUser',
SECRET = N'mypassword!';
GO
/* bind to credential */
USE master;
GO
ALTER LOGIN Gargouille
WITH CREDENTIAL = AccountingGroup;
GO
