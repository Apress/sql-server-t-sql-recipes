/* 24-7 */
USE AdventureWorks2014;
GO
CREATE STATISTICS Stats_SalesOrderDetail_UnitPrice_Filtered ON Sales.SalesOrderDetail (UnitPrice) 
WHERE UnitPrice >= 1000.00 AND UnitPrice <= 1500.00 
WITH FULLSCAN;
