/* 30-14 */
/* query for possible groups */
USE master;
GO
SELECT name
FROM sys.dm_audit_actions
WHERE class_desc = 'SERVER' 
AND configuration_level = 'Group' 
ORDER BY name;
GO

/* create the audit spec */
USE master;
GO
CREATE SERVER AUDIT SPECIFICATION TroisMots_Server_Audit_Spec FOR SERVER AUDIT TroisMots_Server_Audit
ADD (SERVER_ROLE_MEMBER_CHANGE_GROUP),
ADD (DBCC_GROUP),
ADD (BACKUP_RESTORE_GROUP) WITH (STATE = ON);
GO

/* validate the audit spec was created */
USE master;
GO
SELECT server_specification_id,name,is_state_enabled
FROM sys.server_audit_specifications;
GO

/* verify the details and groups of the spec */
USE master;
GO
SELECT server_specification_id,audit_action_name
FROM sys.server_audit_specification_details
WHERE server_specification_id = 65536;
GO

