/* 28-7 */
USE master;
GO
IF EXISTS (SELECT name FROM sys.databases WHERE name = 'RoisdeFrance')
BEGIN
DROP DATABASE RoisdeFrance;
END
CREATE DATABASE RoisdeFrance;
GO

ALTER DATABASE RoisdeFrance
SET RECOVERY FULL;
GO

BACKUP DATABASE RoisdeFrance
TO DISK = 'C:\Apress\RoisdeFrance_A.bak';
GO
USE RoisdeFrance;
GO
CREATE TABLE Rois
(IDRoi int NOT NULL PRIMARY KEY IDENTITY(1,1), NomDuRoi varchar(255));
GO

INSERT INTO Rois (NomDuRoi)
    VALUES ('Charlemagne'), ('Napoleon I'), ('Louis VI le Gros'), ('Lothair');
BACKUP LOG RoisdeFrance
TO DISK = 'C:\Apress\RoisdeFrance_A.trn';
GO

/* check for forks */
USE msdb;
GO
SELECT last_log_backup_lsn AS LastLSN
    ,recovery_fork_guid AS Rec_Fork 
    ,first_recovery_fork_guid AS Frst_Fork
	,fork_point_lsn AS Fork_LSN
FROM sys.database_recovery_status 
WHERE database_id = DB_ID('RoisdeFrance');
GO

/* make some more changes */
USE RoisdeFrance;
GO
INSERT Into Rois (NomDuRoi)
    VALUES ('Thiery I'), ('Thibaut'), ('Dagobert I'), ('Childebert l''Adopt�');
GO
BACKUP LOG RoisdeFrance
TO DISK = 'C:\Apress\RoisdeFrance_B.trn';
GO

/* now restore to previous state */
USE master;
GO
RESTORE DATABASE RoisdeFrance
FROM DISK = 'C:\Apress\RoisdeFrance_A.bak'
WITH NORECOVERY, REPLACE;
RESTORE DATABASE RoisdeFrance
FROM DISK = 'C:\Apress\RoisdeFrance_A.trn'
WITH RECOVERY, REPLACE;
GO

/* check for forks */
USE msdb;
GO
SELECT last_log_backup_lsn AS LastLSN
    ,recovery_fork_guid AS Rec_Fork 
    ,first_recovery_fork_guid AS Frst_Fork
	,fork_point_lsn AS Fork_LSN
FROM sys.database_recovery_status 
WHERE database_id = DB_ID('RoisdeFrance');
GO
