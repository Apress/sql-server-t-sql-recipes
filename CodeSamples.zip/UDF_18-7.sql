/* 18-7 */
Use AdventureWorks2014;
GO
CREATE TABLE dbo.DimProductSalesperson
(DimProductSalespersonID int IDENTITY(1,1) NOT NULL PRIMARY KEY,
ProductCD char(10) NOT NULL,
CompanyNBR int NOT NULL,
SalespersonNBR int NOT NULL );
GO

/* Create staging table */

Use AdventureWorks2014;
GO
CREATE TABLE dbo.Staging_PRODSLSP ( ProductCD char(10) NOT NULL,
CompanyNBR int NOT NULL,
SalespersonNBR int NOT NULL );
GO

/* Next, I�ll insert two rows into the staging table. */
Use AdventureWorks2014;
GO
INSERT dbo.Staging_PRODSLSP (ProductCD, CompanyNBR, SalespersonNBR) 
      VALUES ('2391A23904', 1, 24);
INSERT dbo.Staging_PRODSLSP (ProductCD, CompanyNBR, SalespersonNBR) 
      VALUES ('X129483203', 1, 34);
GO

/* insert into prod table */
Use AdventureWorks2014;
GO
INSERT Into dbo.DimProductSalesperson (ProductCD, CompanyNBR, SalespersonNBR) 
      SELECT s.ProductCD, s.CompanyNBR, s.SalespersonNBR 
            FROM dbo.Staging_PRODSLSP s 
            LEFT OUTER JOIN dbo.DimProductSalesperson d 
                  ON s.ProductCD = d.ProductCD 
                  AND s.CompanyNBR = d.CompanyNBR 
                  AND s.SalespersonNBR = d.SalespersonNBR 
      WHERE d.DimProductSalespersonID IS NULL;
GO

/* now create a udf */
Use AdventureWorks2014;
GO
CREATE FUNCTION dbo.udf_GET_Check_NK_DimProductSalesperson (@ProductCD char(10), @CompanyNBR int, @SalespersonNBR int ) 
RETURNS bit 
AS 
BEGIN
DECLARE @Exists bit
IF EXISTS (SELECT DimProductSalespersonID 
            FROM dbo.DimProductSalesperson 
            WHERE @ProductCD = @ProductCD 
            AND @CompanyNBR = @CompanyNBR 
            AND @SalespersonNBR = @SalespersonNBR) 
BEGIN
      SET @Exists = 1;
END 
ELSE 
BEGIN
      SET @Exists = 0;
END
RETURN @Exists 
END
GO

/* rewritten insert statement */
Use AdventureWorks2014;
GO
INSERT INTO dbo.DimProductSalesperson(ProductCD, CompanyNBR, SalespersonNBR)
      SELECT ProductCD, CompanyNBR, SalespersonNBR
      FROM dbo.Staging_PRODSLSP
      WHERE dbo.udf_GET_Check_NK_DimProductSalesperson
       (ProductCD, CompanyNBR, SalespersonNBR) = 0;
GO
