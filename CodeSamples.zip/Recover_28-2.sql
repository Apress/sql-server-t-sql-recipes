/* 28-2 */
USE master;
GO
IF NOT EXISTS (SELECT name FROM sys.databases
WHERE name = 'TrainingDB') 
BEGIN
CREATE DATABASE TrainingDB;
END 
GO
-- Add a table and some data to it
USE TrainingDB
GO
SELECT *
--INTO dbo.SalesOrderDetail
FROM AdventureWorks2014.Sales.SalesOrderDetail;
GO

USE master;
GO

Declare @BackupDate Char(8) = Convert(Varchar,GetDate(),112)
    ,@BackupPath Varchar(50);
	
Set @BackupPath= 'C:\Apress\TrainingDB_'+ @BackupDate + '.BAK';

BACKUP DATABASE TrainingDB
TO DISK = @BackupPath;
GO
BACKUP LOG TrainingDB
TO DISK = 'C:\Apress\TrainingDB_20150430_8AM.trn';
GO
-- Two hours pass, another transaction log backup is made
BACKUP LOG TrainingDB
TO DISK = 'C:\Apress\TrainingDB_20150430_10AM.trn';
GO

/* kick out any users */
USE master; 
GO
-- Kicking out all other connections
ALTER DATABASE TrainingDB
SET SINGLE_USER
WITH ROLLBACK IMMEDIATE;
GO

/* restore database */
USE master;
GO
Declare @DeviceName Varchar(50);

Select @DeviceName = b.physical_device_name
    From msdb.dbo.backupset a
        INNER JOIN msdb.dbo.backupmediafamily b
            ON a.media_set_id = b.media_set_id
    Where a.database_name = 'TrainingDB'
        And a.type = 'D'
        And Convert(Varchar,a.backup_start_date,112) = Convert(Varchar,GetDate(),112);
RESTORE DATABASE TrainingDB
FROM DISK = @DeviceName
WITH NORECOVERY, REPLACE;

RESTORE LOG TrainingDB
FROM DISK = 'C:\Apress\TrainingDB_20150430_8AM.trn'
WITH NORECOVERY, REPLACE;

RESTORE LOG TrainingDB
FROM DISK = 'C:\Apress\TrainingDB_20150430_10AM.trn'
WITH RECOVERY, REPLACE;
GO

/* backup for stopat example */
USE master;
GO
BACKUP DATABASE TrainingDB
TO DISK = 'C:\Apress\TrainingDB_StopAt.bak';
GO

USE TrainingDB;
GO
DELETE dbo.SalesOrderDetail
WHERE ProductID = 776;
GO
SELECT GETDATE();
GO

--2015-03-20 09:15:27.047

/* tlog backup */

BACKUP LOG TrainingDB
TO DISK = 'C:\Apress\TrainingDB_20150320_0915.trn';
GO

/* perform the restores */
USE master;
GO
RESTORE DATABASE TrainingDB
FROM DISK = 'C:\Apress\TrainingDB_StopAt.bak'
WITH FILE = 1, NORECOVERY,
STOPAT = '2015-03-20 09:15:27.007';
GO

RESTORE LOG TrainingDB
FROM DISK = 'C:\Apress\TrainingDB_20150320_0915.trn'
WITH RECOVERY,
STOPAT = '2015-03-20 09:15:27.007';
GO

/* query the table */
USE TrainingDB;
GO
SELECT COUNT(*)
FROM dbo.SalesOrderDetail
WHERE ProductID = 776;
GO
