/* 30-9 */
EXECUTE AS LOGIN ='testuser';

USE AdventureWorks2014;
GO
SELECT HAS_PERMS_BY_NAME ('AdventureWorks2014', 'DATABASE', 'ALTER');
GO

REVERT

EXECUTE AS LOGIN ='testuser';
/* check for update perms */
USE AdventureWorks2014;
GO
SELECT UpdateTable = CASE HAS_PERMS_BY_NAME ('Person.Address', 'OBJECT', 'UPDATE') WHEN 1 THEN 'Yes' ELSE 'No' END ,
SelectFromTable = CASE HAS_PERMS_BY_NAME ('Person.Address', 'OBJECT', 'SELECT') WHEN 1 THEN 'Yes' ELSE 'No' END;
GO
REVERT