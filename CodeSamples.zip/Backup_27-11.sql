/* 27-11 */
USE master;
GO

BACKUP DATABASE AdventureWorks2014
TO DISK =  'C:\Apress\AdventureWorks2014Copydiff.bak'
WITH COPY_ONLY;
GO

/* check the backups */

USE msdb;
GO

Select bs.database_name, bs.backup_finish_date
	, CASE bs.type
		WHEN 'D' THEN 'Full Database'
		WHEN 'I' THEN 'Differential Database'
		WHEN 'L' THEN 'Log'
		WHEN 'F' THEN 'File or filegroup'
		WHEN 'G' THEN 'Differential file'
		WHEN 'P' THEN 'Partial'
		WHEN 'Q' THEN 'Differential partial'
		END AS BackupType
	,bs.is_copy_only, bs.recovery_model,bs.has_backup_checksums
	,bs.backup_size/1024/1024 as BackSizeMB
	From backupset bs;