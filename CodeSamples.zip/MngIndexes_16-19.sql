/* 15-18 */
Use AdventureWorks2014;
GO
CREATE NONCLUSTERED INDEX NCI_SalesOrderDetail_CarrierTrackingNumber 
  ON Sales.SalesOrderDetail (CarrierTrackingNumber) 
  WITH (DATA_COMPRESSION = PAGE);

--change to row level compression
Use AdventureWorks2014;
GO
ALTER INDEX NCI_SalesOrderDetail_CarrierTrackingNumber
  ON Sales.SalesOrderDetail
  REBUILD WITH (DATA_COMPRESSION = ROW);

