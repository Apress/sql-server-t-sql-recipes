/* 18-9 */
Use AdventureWorks2014;
GO
DROP FUNCTION dbo.udf_ParseArray;
