/* 20-1 */

USE AdventureWorks2014;
GO

CREATE TABLE Production.ProductInventoryAudit
       (
        ProductID INT NOT NULL,
        LocationID SMALLINT NOT NULL,
        Shelf NVARCHAR(10) NOT NULL,
        Bin TINYINT NOT NULL,
        Quantity SMALLINT NOT NULL,
        rowguid UNIQUEIDENTIFIER NOT NULL,
        ModifiedDate DATETIME NOT NULL,
        InsertOrDelete CHAR(1) NOT NULL
       );
GO
-- Create trigger to populate Production.ProductInventoryAudit table
CREATE TRIGGER Production.trg_id_ProductInventoryAudit ON Production.ProductInventory
       AFTER INSERT, DELETE
AS
BEGIN
       SET NOCOUNT ON;
-- Inserted rows
       INSERT INTO Production.ProductInventoryAudit
                (ProductID,
                 LocationID,
                 Shelf,
                 Bin,
                 Quantity,
                 rowguid,
                 ModifiedDate,
                 InsertOrDelete)
                SELECT DISTINCT
                        i.ProductID,
                        i.LocationID,
                        i.Shelf,
                        i.Bin,
                        i.Quantity,
                        i.rowguid,
                        GETDATE(),
                        'I'
                FROM    inserted i
                UNION ALL
                SELECT  d.ProductID,
                        d.LocationID,
                        d.Shelf,
                        d.Bin,
                        d.Quantity,
                        d.rowguid,
                        GETDATE(),
                        'D'
                FROM    deleted d;

END
GO

-- Insert a new row 
INSERT INTO Production.ProductInventory
        (ProductID,
         LocationID,
         Shelf,
         Bin,
         Quantity)
VALUES  (316,
         6,
         'A',
         4,
         22);

-- Delete a row
DELETE  
FROM Production.ProductInventory
WHERE   ProductID = 316
        AND LocationID = 6;

-- Check the audit table
SELECT  ProductID,
        LocationID,
        InsertOrDelete
FROM    Production.ProductInventoryAudit;
