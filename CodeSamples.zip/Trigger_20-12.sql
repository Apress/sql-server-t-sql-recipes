/* 20-12 */
-- Allow recursion
ALTER DATABASE AdventureWorks2014
SET RECURSIVE_TRIGGERS ON ;

-- View the db setting
SELECT  name as DBName,is_recursive_triggers_on
FROM    sys.databases
WHERE   name = 'AdventureWorks2014' ;

-- Prevents recursion
ALTER DATABASE AdventureWorks2014
SET RECURSIVE_TRIGGERS OFF ;

-- View the db setting
SELECT  name as DBName,is_recursive_triggers_on
FROM    sys.databases
WHERE   name = 'AdventureWorks2014' ;
