/* 24-12 */
USE AdventureWorks2014;
GO
DROP STATISTICS Sales.SalesOrderDetail.Stats_SalesOrderDetail_UnitPrice_Filtered;
