/* 27-13 */
-- Create a DMK. 
-- The DMK is encrypted using the password "SQL2014Rocks"
USE master;
GO
CREATE MASTER KEY ENCRYPTION BY PASSWORD = 'SQL2014Rocks';
GO

--create our encryptor
USE master;
GO
CREATE CERTIFICATE AW2014BackupCert
   WITH SUBJECT = 'AdventureWorks2014 Backup Encryption Certificate';
GO

--backup the database
USE master;
GO

BACKUP DATABASE AdventureWorks2014
TO DISK = N'C:\Apress\AdventureWorks2014_enc.bak'
WITH
  ENCRYPTION 
   (
   ALGORITHM = AES_256,
   SERVER CERTIFICATE = AW2014BackupCert
   ),
  STATS = 5
GO

-- check the backups
USE msdb;
GO
SELECT bs.database_name,
	   bs.backup_start_date,
	   CASE bs.type
	     WHEN 'D' THEN 'Full Database'
	     WHEN 'I' THEN 'Differential Database' 
	     WHEN 'L' THEN 'Log' 
	     WHEN 'F' THEN 'File or Filegroup' 
	     WHEN 'G' THEN 'Differential File'
	     WHEN 'P' THEN 'Partial'
	     WHEN 'Q' THEN 'Differential Partial'
	     ELSE 'Unknown'
	   END AS BackupType,
	   bmf.physical_device_name,
	   bs.backup_size/1024/1024 as BackSizeMB,
	   bs.encryptor_type, bs.key_algorithm
FROM backupset bs 
INNER JOIN backupmediafamily bmf
ON bs.media_set_id = bmf.media_set_id
WHERE bs.key_algorithm IS NOT NULL
ORDER BY bs.database_name,bs.backup_start_date DESC;
GO