/* 18-11 */
Use AdventureWorks2014;
GO
SELECT Table_Name = OBJECT_NAME(c.object_id) , Column_name = c.name 
FROM sys.columns c
      INNER JOIN sys.types t 
            ON c.user_type_id = t.user_type_id 
WHERE t.name = 'AccountNBR';

Use AdventureWorks2014;
GO
/*
-- Now see what parameters reference the AccountNBR data type 
*/
SELECT ProcFunc_Name = OBJECT_NAME(p.object_id) , Parameter_Name = p.name  
FROM sys.parameters p 
      INNER JOIN sys.types t 
            ON p.user_type_id = t.user_type_id 
WHERE t.name = 'AccountNBR';
