/* 29-9 */
USE master;
GO
SELECT p.name, ca.IsLocked, ca.IsExpired, ca.IsMustChange, ca.BadPasswordCount, ca.BadPasswordTime, ca.HistoryLength, ca.LockoutTime,ca.PasswordLastSetTime,ca.DaysUntilExpiration
    From sys.server_principals p
        CROSS APPLY (SELECT  IsLocked = LOGINPROPERTY(p.name,  'IsLocked') ,
        IsExpired = LOGINPROPERTY(p.name,  'IsExpired') ,
        IsMustChange = LOGINPROPERTY(p.name,  'IsMustChange') ,
        BadPasswordCount = LOGINPROPERTY(p.name,  'BadPasswordCount') ,
        BadPasswordTime = LOGINPROPERTY(p.name,  'BadPasswordTime') ,
        HistoryLength = LOGINPROPERTY(p.name,  'HistoryLength') ,
        LockoutTime = LOGINPROPERTY(p.name,  'LockoutTime') ,
        PasswordLastSetTime = LOGINPROPERTY(p.name,  'PasswordLastSetTime') ,
        DaysUntilExpiration = LOGINPROPERTY(p.name,  'DaysUntilExpiration') 
    ) ca
    WHERE p.type_desc = 'SQL_LOGIN'
        AND p.is_disabled = 0;
GO

USE master;
GO
SELECT p.name,ca.DefaultDatabase,ca.DefaultLanguage,ca.PasswordHash
    ,PasswordHashAlgorithm = Case ca.PasswordHashAlgorithm 
        WHEN 1
        THEN 'SQL7.0'
        WHEN 2
        THEN 'SHA-1'
        WHEN 3
        THEN 'SHA-2'
        ELSE 'login is not a valid SQL Server login'
        END
    FROM sys.server_principals p
    CROSS APPLY (SELECT  PasswordHash = LOGINPROPERTY(p.name,  'PasswordHash') ,
        DefaultDatabase = LOGINPROPERTY(p.name,  'DefaultDatabase') ,
        DefaultLanguage = LOGINPROPERTY(p.name,  'DefaultLanguage') ,
        PasswordHashAlgorithm = LOGINPROPERTY(p.name,  'PasswordHashAlgorithm')
    ) ca
    WHERE p.type_desc = 'SQL_LOGIN'
        AND p.is_disabled = 0;
GO
