/* 27-1 */
USE master;
GO

BACKUP DATABASE AdventureWorks2014
TO DISK = 'C:\Apress\AdventureWorks2014.bak';
GO
