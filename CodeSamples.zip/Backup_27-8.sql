/* 27-8 */
/* create a snapshot */
USE master;
GO

CREATE DATABASE AdventureWorks2014_SS ON
( NAME = AdventureWorks2014_Data, FILENAME = 
'C:\Apress\AdventureWorks2014_SS.ss' )
AS SNAPSHOT OF AdventureWorks2014;
GO

USE master;
GO

SELECT DB_NAME(database_id) AS DBName,
     name AS FileName,
	 type_desc,
	 size
FROM sys.master_files
WHERE DB_NAME(database_id) LIKE 'AdventureWorks2014%'
	AND type_desc = 'ROWS';
GO

/* find snapshots */
USE master;
GO

SELECT d.name AS DBName,
	 DB_NAME(d.source_database_id) AS SourceDB,
	 d.create_date,
	 d.is_read_only,
	 mf.is_sparse
FROM sys.master_files mf
	INNER JOIN sys.databases d
		ON d.database_id = mf.database_id
WHERE d.name LIKE 'AdventureWorks2014%'
	AND type_desc = 'ROWS';
GO
