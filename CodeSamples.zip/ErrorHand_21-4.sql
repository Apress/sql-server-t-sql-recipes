/* 21-4 */
USE tempdb;
GO

BEGIN TRY
   SELECT 1/0
END TRY
BEGIN CATCH
    PRINT 'In catch block.';
    THROW;
END CATCH; 

/* custom error with THROW */
USE tempdb;
GO

BEGIN TRY
   SELECT 1/0
END TRY
BEGIN CATCH
	IF (SELECT @@ERROR) = 8134
	BEGIN;
	THROW 51000, 'Divide by zero error occurred', 10;
	  END 
	  ELSE
	THROW 52000, 'Unknown error occurred', 10;
END CATCH;
