/* 30-1 */
USE master;
GO

SELECT class_desc, permission_name, covering_permission_name, parent_class_desc, parent_covering_permission_name 
    FROM sys.fn_builtin_permissions(DEFAULT) 
    ORDER BY class_desc, permission_name; 
GO

/* schema comparable scope */
USE master;
GO

SELECT permission_name, covering_permission_name, parent_class_desc 
    FROM sys.fn_builtin_permissions('schema') 
    ORDER BY permission_name;
GO
