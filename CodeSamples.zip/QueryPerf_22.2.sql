/* 22-2 */
USE AdventureWorks2014;
GO
SET SHOWPLAN_TEXT ON;
GO
SELECT p.Name, p.ProductNumber, r.ReviewerName
FROM Production.Product p
INNER JOIN Production.ProductReview r 
ON p.ProductID = r.ProductID 
WHERE r.Rating > 2;
GO
SET SHOWPLAN_TEXT OFF;
GO

/* XML Format */
USE AdventureWorks2014;
GO
SET SHOWPLAN_XML ON;
GO
SELECT p.Name, p.ProductNumber, r.ReviewerName
FROM Production.Product p
INNER JOIN Production.ProductReview r 
ON p.ProductID = r.ProductID 
WHERE r.Rating > 2;
GO
SET SHOWPLAN_XML OFF;
GO
