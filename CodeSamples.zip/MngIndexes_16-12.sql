/* 15-11 */

USE AdventureWorks2014;
GO
CREATE NONCLUSTERED INDEX NCI_ProductVendor_MinOrderQty 
  ON Purchasing.ProductVendor(MinOrderQty) 
  WITH (ONLINE = ON); -- Online option is an Enterprise Edition feature
