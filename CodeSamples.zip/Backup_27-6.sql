/* 27-6 */
USE master;
GO

BACKUP DATABASE AdventureWorks2014
TO DISK =  'C:\Apress\AdventureWorks2014_diff.bak'
WITH DIFFERENTIAL;
GO
