/* 27-15 */
USE master;
GO

BACKUP CERTIFICATE AW2014BackupCert 
TO FILE = 'c:\Apress\AW2014BackupCert.cer'
WITH PRIVATE KEY ( FILE = 'C:\Apress\AW2014BackupCertKey.bak' ,
ENCRYPTION BY PASSWORD = 'SQL2014Rocks');
GO

/* DMK should also be backed up */
OPEN MASTER KEY DECRYPTION BY PASSWORD = 'SQL2014Rocks';
BACKUP MASTER KEY TO FILE = 'c:\Apress\exportedmasterkey.key' 
    ENCRYPTION BY PASSWORD = 'SQL2014Rocks';
GO 

/* validate the key and cert are backed up */
USE master;
GO

SELECT name, pvt_key_encryption_type_desc,pvt_key_last_backup_date
	FROM sys.certificates
	WHERE name = 'AW2014BackupCert';
