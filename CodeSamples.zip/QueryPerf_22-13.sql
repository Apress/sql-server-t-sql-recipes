/* 22-13 */
USE AdventureWorks2014;
GO
SELECT pg.plan_guide_id, pg.name, v.msgnum,
v.severity, v.state, v.message 
FROM sys.plan_guides pg 
CROSS APPLY sys.fn_validate_plan_guide(pg.plan_guide_id) v;
