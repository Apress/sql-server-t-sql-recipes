/* 28-8 */
USE master;
GO

IF EXISTS (SELECT * FROM sys.databases WHERE name = 'Granular')
BEGIN
DROP DATABASE Granular;
END
CREATE DATABASE Granular;
GO

USE Granular;
GO

CREATE SCHEMA Person;
GO

USE Granular;
GO

SELECT BusinessEntityID,
	 FirstName,
	 MiddleName,
	 LastName
INTO Person.Person
FROM AdventureWorks2014.Person.Person;
GO

SELECT TOP 6 *
FROM Person.Person
ORDER BY BusinessEntityID;
GO

/* backup and delete a record */

USE master;
GO
BACKUP DATABASE Granular
TO DISK = 'C:\Apress\Granular.bak';
GO

USE Granular;
GO
DELETE p
FROM Person.Person p
WHERE p.BusinessEntityID = 1;
GO

SELECT TOP 6 *
FROM Person.Person
ORDER BY BusinessEntityID;
GO

/* recover the deleted data */
USE master;
GO
 
RESTORE DATABASE Granular_COPY 
FROM  DISK = 'C:\Apress\Granular.bak' 
WITH MOVE N'Granular' TO 'C:\Apress\Granular_COPY.mdf',  
MOVE N'Granular_log' TO N'C:\Apress\Granular_log_COPY.ldf';
GO

USE Granular;
GO

INSERT INTO Person.Person
SELECT BusinessEntityID,
	 FirstName,
	 MiddleName,
	 LastName
FROM AdventureWorks2014.Person.Person
WHERE BusinessEntityID = 1;
GO

SELECT TOP 6 *
FROM Person.Person
ORDER BY BusinessEntityID;
GO

/* via snapshot */
USE master;
GO

IF EXISTS (SELECT * FROM sys.databases WHERE name = 
'Original')
BEGIN
DROP DATABASE Original;
END
CREATE DATABASE Original;
GO

USE Original;
GO

CREATE SCHEMA Person;
GO

SELECT BusinessEntityID,
	 FirstName,
	 MiddleName,
	 LastName
INTO Person.Person
FROM AdventureWorks2014.Person.Person;
GO

CREATE DATABASE Original_SS ON
( NAME = Original, FILENAME = 
'C:\Apress\Original_SS.ss' )
AS SNAPSHOT OF Original;
GO

USE Original_SS;
GO

SELECT *
FROM Person.Person
WHERE LastName = 'Abercrombie';
GO


USE Original;
GO

UPDATE Person.Person
SET LastName = 'Abercromny'
WHERE LastName = 'Abercrombie';
GO

SELECT *
FROM Person.Person
WHERE LastName = 'Abercrombie';
GO

USE Original_SS
GO

SELECT *
FROM Person.Person
WHERE LastName = 'Abercrombie';
GO

/* get the data back */

USE Original;
GO

UPDATE Person.Person
SET LastName = ss.LastName
FROM Person.Person p 
INNER JOIN Original_SS.Person.Person ss
ON p.LastName <> ss.LastName
AND p.BusinessEntityID = ss.BusinessEntityID;
GO

SELECT *
FROM Person.Person
WHERE LastName = 'Abercrombie';
GO

/* revert the database */
USE master;

RESTORE DATABASE Original
FROM DATABASE_SNAPSHOT = 'Original_SS';
GO
