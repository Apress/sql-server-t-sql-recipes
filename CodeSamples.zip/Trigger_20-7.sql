/* 20-7 */
USE master;
GO
CREATE LOGIN nightworker WITH PASSWORD = 'pass@word1' ;
GO

/* audit DB and table */
CREATE DATABASE ExampleAuditDB ;
GO
USE ExampleAuditDB ;
GO
CREATE TABLE dbo.RestrictedLogonAttempt
       (
        LoginName SYSNAME NOT NULL,
        AttemptDate DATETIME NOT NULL
       ) ;
GO

/* Create Trigger */
USE master ;
GO
CREATE TRIGGER trg_logon_attempt ON ALL SERVER
 WITH EXECUTE AS 'sa'
       FOR LOGON
AS
       BEGIN
             IF ORIGINAL_LOGIN() = 'nightworker'
                AND DATEPART(hh, GETDATE()) BETWEEN 7 AND 18 
                BEGIN
                      ROLLBACK ;
                      INSERT    ExampleAuditDB.dbo.RestrictedLogonAttempt
                                (LoginName, AttemptDate)
                      VALUES    (ORIGINAL_LOGIN(), GETDATE()) ;
                END 
       END 
GO
