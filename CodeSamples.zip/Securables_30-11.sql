/* 30-11 */
USE AdventureWorks2014;
GO
ALTER AUTHORIZATION ON Schema::HumanResources TO TestUser;
GO

/* In case an endpoint does not exist let's create one */
CREATE ENDPOINT ProductMirror
    STATE = STOPPED
    AS TCP ( LISTENER_PORT = 7022 )
    FOR DATABASE_MIRRORING (ROLE=PARTNER);
/* In 2014, only the following endpoints are available 
TSQL | SERVICE_BROKER | DATABASE_MIRRORING
*/

USE AdventureWorks2014;
GO
SELECT p.name OwnerName
FROM sys.endpoints e
INNER JOIN sys.server_principals p 
ON e.principal_id = p.principal_id 
WHERE e.name = 'ProductMirror';
GO

/* change the owner of the endpoint */
USE AdventureWorks2014;
GO
ALTER AUTHORIZATION ON ENDPOINT::ProductMirror TO TestUser;
GO

/* Cleanup the endpoint */
DROP ENDPOINT ProductMirror;
GO