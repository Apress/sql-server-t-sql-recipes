/* 30-15 */
USE master;
GO
SELECT name
FROM sys.dm_audit_actions
WHERE configuration_level = 'Action' 
AND class_desc = 'OBJECT' 
ORDER BY name;
GO

/* database scope */
USE master;
GO
SELECT name
FROM sys.dm_audit_actions
WHERE configuration_level = 'Group' 
AND class_desc = 'DATABASE' 
ORDER BY name;
GO

/*audit any insert update or delete*/
USE AdventureWorks2014;
GO
CREATE DATABASE AUDIT SPECIFICATION AdventureWorks2014_DB_Spec 
    FOR SERVER AUDIT TroisMots_Server_Audit 
    ADD (DATABASE_PRINCIPAL_IMPERSONATION_GROUP)
    , ADD (INSERT, UPDATE, DELETE ON Sales.CreditCard BY public) 
WITH (STATE = ON);
GO

/* validate */
USE AdventureWorks2014;
GO
SELECT database_specification_id,name,is_state_enabled 
FROM sys.database_audit_specifications;
GO

/* details */
USE AdventureWorks2014;
GO
SELECT audit_action_name, class_desc, is_group
,ObjectNM = CASE
    WHEN major_id > 0 THEN OBJECT_NAME(major_id, DB_ID()) ELSE 'N/A' END  
FROM sys.database_audit_specification_details 
WHERE database_specification_id = 65536;
GO
