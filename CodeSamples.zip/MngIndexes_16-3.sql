/* 15-2 */

USE AdventureWorks2014;
GO
CREATE UNIQUE NONCLUSTERED INDEX UNI_TerminationReason ON HumanResources.TerminationReason (TerminationReason);

/*Insert some values */
USE AdventureWorks2014;
GO
INSERT INTO HumanResources.TerminationReason (DepartmentID, TerminationReason) 
  VALUES (1, 'Bad Engineering Skills')
  ,(2, 'Breaks Expensive Tools');


/* Insert a duplicate value */
USE AdventureWorks2014;
GO
INSERT INTO HumanResources.TerminationReason (DepartmentID, TerminationReason) 
	VALUES (2, 'Bad Engineering Skills');
