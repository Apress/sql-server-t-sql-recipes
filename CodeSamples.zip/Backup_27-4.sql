/* 27-4 */
/* simplest option */
BACKUP LOG AdventureWorks2014
TO DISK = 'C:\Apress\AdventureWorks2014.trn';
GO

/* to allow flexibility */
DECLARE @DiskPath VARCHAR(256)
	, @DBName sysname = 'AdventureWorks2014';

SET @DiskPath = 'C:\Apress\' + @DBName + '_'
	+ REPLACE(REPLACE(REPLACE(CONVERT(CHAR(19), GETDATE(), 126), ' ', '_'), '-',
						''), ':', '') + '.trn';

BACKUP LOG @DBName
	TO DISK = @DiskPath
	WITH INIT,CHECKSUM,COMPRESSION;
GO