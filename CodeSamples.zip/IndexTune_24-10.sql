/* 24-10 */
USE AdventureWorks2014;
GO
EXECUTE sp_updatestats;
GO
