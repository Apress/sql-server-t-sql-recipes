/* 30-13 */
USE master;
GO
CREATE SERVER AUDIT TroisMots_Server_Audit TO FILE
( FILEPATH = 'C:\Apress\',
MAXSIZE = 500 MB,
MAX_ROLLOVER_FILES = 10,
RESERVE_DISK_SPACE = OFF) WITH ( QUEUE_DELAY = 1000,
ON_FAILURE = CONTINUE);
GO

/* confirm the audit created */
USE master;
GO
SELECT sa.audit_id,sa.type_desc,sa.on_failure_desc
    ,sa.queue_delay,sa.is_state_enabled
	,sfa.log_file_path
FROM sys.server_audits sa
	INNER JOIN sys.server_file_audits sfa
		ON sa.audit_guid = sfa.audit_guid
	WHERE sa.name = 'TroisMots_Server_Audit'
GO

USE master;
GO
SELECT  name,
log_file_path,
log_file_name,
max_rollover_files,
max_file_size 
FROM sys.server_file_audits;
GO

/* try one with a predicate */
USE master;
GO
CREATE SERVER AUDIT TroisMots_CC_Server_Audit TO FILE
     ( FILEPATH = 'C:\Apress\',
    MAXSIZE = 500 MB,
    MAX_ROLLOVER_FILES = 10,
    RESERVE_DISK_SPACE = OFF) WITH ( QUEUE_DELAY = 1000,
    ON_FAILURE = CONTINUE)
WHERE database_name ='AdventureWorks2014' AND schema_name ='Sales' 
  AND object_name ='CreditCard' AND database_principal_name ='dbo';
GO

USE master;
GO
SELECT  name,
log_file_path,
log_file_name,
max_rollover_files,
max_file_size,
predicate
FROM sys.server_file_audits sfs
WHERE sfs.name = 'TroisMots_CC_Server_Audit';
GO
