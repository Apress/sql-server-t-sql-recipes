/* 29-7 */
USE master;
GO
SELECT name, sid 
FROM sys.server_principals 
WHERE type_desc IN ('SQL_LOGIN') 
ORDER BY name;
GO
