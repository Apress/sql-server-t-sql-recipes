/* 15-8 */

/* rebuild existing index via drop_existing */
USE AdventureWorks2014;
GO
CREATE NONCLUSTERED INDEX NI_TerminationReason_TerminationReason_DepartmentID 
  ON HumanResources.TerminationReason(TerminationReason, DepartmentID)
WITH (DROP_EXISTING = ON);
GO

/* add a new column to a non-clustered index */

USE AdventureWorks2014;
GO
CREATE NONCLUSTERED INDEX NI_TerminationReason_TerminationReason_DepartmentID 
  ON HumanResources.TerminationReason(TerminationReason, ViolationSeverityLevel, DepartmentID DESC)
WITH (DROP_EXISTING = ON);
GO

