/* 20-10 */
USE AdventureWorks2014;
GO

CREATE TRIGGER HumanResources.trg_Department ON HumanResources.Department
       AFTER INSERT
AS
       PRINT 'The trg_Department trigger was fired' ;
GO

/* Disable Trigger */
USE AdventureWorks2014;
GO

DISABLE TRIGGER HumanResources.trg_Department 
	ON HumanResources.Department ;

/* Enable Trigger */
USE AdventureWorks2014;
GO

ENABLE TRIGGER HumanResources.trg_Department 
	ON HumanResources.Department ;