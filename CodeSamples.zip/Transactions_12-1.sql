/* 12-1 */
USE AdventureWorks2014;
GO
/* -- Before count */
SELECT BeforeCount = COUNT(*)  
FROM HumanResources.Department;
/* -- Variable to hold the latest error integer value */
DECLARE @Error int;
BEGIN TRANSACTION
INSERT INTO HumanResources.Department (Name, GroupName)
    VALUES ('Accounts Payable', 'Accounting');
SET @Error = @@ERROR;
IF (@Error<> 0) 
    GOTO Error_Handler;
INSERT INTO HumanResources.Department (Name, GroupName)
    VALUES ('Engineering', 'Research and Development');
SET @Error = @@ERROR;
IF (@Error <> 0) 
    GOTO Error_Handler;
COMMIT TRANSACTION
Error_Handler: 
IF @Error <> 0 
BEGIN
ROLLBACK TRANSACTION;
END
/* -- After count */
SELECT AfterCount = COUNT(*) 
FROM HumanResources.Department;  
GO

