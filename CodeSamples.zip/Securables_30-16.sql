/* 30-16 */
USE master;
GO
ALTER SERVER AUDIT [TroisMots_Server_Audit] WITH (STATE = ON);
GO

USE master;
GO
/*
-- Create new login (not auditing this, but using it for recipe) 
*/
CREATE LOGIN TestAudit WITH PASSWORD = 'C83D7F50-9B9E';
GO
/*
-- Add to server role bulkadmin
*/
EXECUTE sp_addsrvrolemember 'TestAudit', 'bulkadmin';
GO
/*
-- Back up AdventureWorks2014 database 
*/
BACKUP DATABASE AdventureWorks2014 TO DISK = 'C:\Apress\Example_AW.BAK';
GO
/*
-- Perform a DBCC on AdventureWorks2014 
*/
DBCC CHECKDB('AdventureWorks2014');
GO
/*
-- Perform some AdventureWorks2014 actions
*/
USE AdventureWorks2014
GO
/*
-- Create a new user and then execute under that
-- user's context
*/
CREATE USER TestAudit FROM LOGIN TestAudit
EXECUTE AS USER = 'TestAudit'
/*
-- Revert back to me (in this case a login with sysadmin perms) 
*/
REVERT;
GO
/*
-- Perform an INSERT, UPDATE, and DELETE -- from Sales.CreditCard
*/
INSERT Into Sales.CreditCard (CardType, CardNumber,ExpMonth,ExpYear,ModifiedDate)
    VALUES('Vista', '8675309153332145',11,2003,GetDate());

UPDATE Sales.CreditCard SET CardType = 'Colonial'
    WHERE CardNumber = '8675309153332145';
DELETE Sales.CreditCard 
    WHERE CardNumber = '8675309153332145';
GO

/* read the audit file */
USE master;
GO
SELECT af.event_time, af.succeeded,
af.target_server_principal_name, object_name 
FROM fn_get_audit_file('C:\Apress\TroisMots_Server_Audit_*', default, default) af 
INNER JOIN sys.dm_audit_actions aa 
    ON af.action_id = aa.action_id 
WHERE aa.name = 'ADD MEMBER' 
    AND aa.class_desc = 'SERVER ROLE';
GO

/* check for actions performed against the CC */
USE master;
GO
SELECT af.event_time,
af.database_principal_name 
FROM fn_get_audit_file('C:\Apress\TroisMots_Server_Audit_*', default, default) af 
INNER JOIN sys.dm_audit_actions aa 
    ON af.action_id = aa.action_id 
WHERE aa.name = 'DELETE' 
    AND aa.class_desc = 'OBJECT' 
    AND af.schema_name = 'Sales' 
    AND af.object_name = 'CreditCard';

/* check backups */
USE master;
GO
SELECT event_time, statement 
FROM fn_get_audit_file('C:\Apress\TroisMots_Server_Audit_*', default, default) af 
INNER JOIN sys.dm_audit_actions aa 
    ON af.action_id = aa.action_id 
WHERE aa.name = 'BACKUP' 
    AND aa.class_desc = 'DATABASE';
GO


/* query for all distinct events*/
USE master;
GO
SELECT DISTINCT
aa.name,
database_principal_name,
target_server_principal_name,
object_name 
FROM fn_get_audit_file('C:\Apress\TroisMots_Server_Audit_*', default, default) af 
INNER JOIN sys.dm_audit_actions aa 
    ON af.action_id = aa.action_id;
GO
