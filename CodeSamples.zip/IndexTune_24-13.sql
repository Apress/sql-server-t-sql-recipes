/* 24-13 */
-- Create database and turn auto create statistics off
USE master;
GO

ALTER DATABASE AdventureWorks2014 
SET AUTO_CREATE_STATISTICS OFF WITH NO_WAIT
GO

USE master;
GO
-- Create the Event Session
IF EXISTS(SELECT * 
          FROM sys.server_event_sessions 
          WHERE name='MissingColumnStats')
    DROP EVENT SESSION MissingColumnStats 
    ON SERVER;
GO
-- Create XEvent session
CREATE EVENT SESSION [MissingColumnStats] ON SERVER 
ADD EVENT sqlserver.missing_column_statistics(SET collect_column_list=(1)
ACTION(sqlserver.sql_text, sqlserver.database_name)) 
ADD TARGET package0.event_file(SET filename=N'C:\Database\XE\MissingColumnStats.xel')
GO
--Start XEvent session
ALTER EVENT SESSION [MissingColumnStats]
ON SERVER
STATE = START
GO

/* baseline our stats */
USE AdventureWorks2014;
GO
SELECT *
	FROM sys.stats
	WHERE OBJECT_NAME(object_id) = 'SalesOrderDetail';
GO

/* Run a query that should generate some statistics need */
USE AdventureWorks2014;
GO
Select Unitprice
	From Sales.SalesOrderDetail 
	WHERE UnitPrice >= 1000.00 AND UnitPrice <= 1500.00;
GO

/* Confirm no new stats */
SELECT *
	FROM sys.stats
	WHERE OBJECT_NAME(object_id) = 'SalesOrderDetail';
GO

/* parse the event data */
use master;
GO

SELECT
event_data.value('(event/@name)[1]', 'varchar(50)') AS event_name,
    event_data.value('(event/@timestamp)[1]', 'varchar(50)') AS [TIMESTAMP],
	event_data.value('(event/action[@name="database_name"]/value)[1]', 'varchar(max)') AS DBName
	,event_data.value('(event/action[@name="sql_text"]/value)[1]', 'varchar(max)') AS SQLText
	,event_data.value('(event/data[@name="column_list"]/value)[1]', 'varchar(max)') AS AffectedColumn
FROM(
SELECT CONVERT(XML, t2.event_data) AS event_data
 FROM (
  SELECT target_data = convert(XML, target_data)
   FROM sys.dm_xe_session_targets t
    INNER JOIN sys.dm_xe_sessions s 
        ON t.event_session_address = s.address
   WHERE t.target_name = 'event_file'
    AND s.name = 'MissingColumnStats') cte1
   CROSS APPLY cte1.target_data.nodes('//EventFileTarget/File') FileEvent(FileTarget)
   CROSS APPLY  sys.fn_xe_file_target_read_file(FileEvent.FileTarget.value('@name', 'varchar(1000)'), NULL, NULL, NULL) t2)
    AS evts(event_data);