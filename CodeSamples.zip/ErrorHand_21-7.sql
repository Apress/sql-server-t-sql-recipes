/* 21-7 */
USE master
GO
EXEC sp_addmessage 50001, 16, 
   N'This is a user defined error that can be corrected by the user';
GO 

/* query sys.messages for the new message */
SELECT message_id,	
	 text
FROM sys.messages
WHERE message_id = 50001;
GO

/* use the new message */
RAISERROR (50001,16,1);
GO

/* adding another message */
USE master
GO
sp_addmessage @msgnum = 50002 , 
        @severity = 16 , 
        @msgtext = 'User error that IS logged', 
        @with_log = 'TRUE';
GO

RAISERROR (50002,16,1);
GO
