/* 29-22 */
USE master;
GO
CREATE SERVER ROLE hdserverstate AUTHORIZATION securityadmin;
GO

GRANT VIEW SERVER STATE TO hdserverstate;
GO

ALTER SERVER ROLE [hdserverstate] ADD MEMBER [Gargouille];
GO

/* check the server role membership */
SELECT sp.name AS RoleName, mem.name AS MemberName
	FROM sys.server_role_members rm
		INNER JOIN sys.server_principals sp
			ON rm.role_principal_id = sp.principal_id
		LEFT OUTER JOIN sys.server_principals mem
			ON rm.member_principal_id = mem.principal_id
	WHERE sp.name = 'hdserverstate'
		AND sp.type_desc = 'SERVER_ROLE';

/* Check to see that the Login can query wait stats */
EXECUTE AS LOGIN = 'Gargouille';
GO
SELECT * FROM sys.dm_os_wait_stats;
GO

REVERT

/* Remove the permissions and verify */
ALTER SERVER ROLE [hdserverstate] DROP MEMBER [Gargouille];
GO 

EXECUTE AS LOGIN = 'Gargouille';
GO
SELECT * FROM sys.dm_os_wait_stats

REVERT

/* remove the server role */
DROP SERVER ROLE [hdserverstate];
GO