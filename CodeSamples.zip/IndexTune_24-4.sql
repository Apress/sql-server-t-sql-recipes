/* 24-4 */
/* create a heap */
USE AdventureWorks2014;
GO
-- Create an unindexed table based on another table 
SELECT ShiftID, Name, StartTime, EndTime, ModifiedDate 
INTO dbo.Heap_Shift 
FROM HumanResources.Shift;

/* confirm the table is a heap */
USE AdventureWorks2014;
GO
SELECT type_desc
FROM sys.indexes 
WHERE object_id = OBJECT_ID('Heap_Shift');

/* rebuild the heap */
USE AdventureWorks2014;
GO
ALTER TABLE dbo.Heap_Shift REBUILD;
