/* 27-14 */
--backup the database
USE master;
GO

BACKUP DATABASE AdventureWorks2014
TO DISK = N'C:\Apress\AdventureWorks2014_compenc.bak'
WITH
  COMPRESSION,
  ENCRYPTION 
   (
   ALGORITHM = AES_256,
   SERVER CERTIFICATE = AW2014BackupCert
   ),
  STATS = 5
GO

USE msdb;
GO
SELECT bs.database_name,
	   bs.backup_start_date,
	   CASE bs.type
	     WHEN 'D' THEN 'Full Database'
	     WHEN 'I' THEN 'Differential Database' 
	     WHEN 'L' THEN 'Log' 
	     WHEN 'F' THEN 'File or Filegroup' 
	     WHEN 'G' THEN 'Differential File'
	     WHEN 'P' THEN 'Partial'
	     WHEN 'Q' THEN 'Differential Partial'
	     ELSE 'Unknown'
	   END AS BackupType,
	   bmf.physical_device_name,
	   bs.backup_size/1024/1024 as BackSizeMB,
	   bs.compressed_backup_size/1024/1024 as CompBackSizeMB,
	   bs.encryptor_type, bs.key_algorithm
FROM backupset bs 
INNER JOIN backupmediafamily bmf
ON bs.media_set_id = bmf.media_set_id
WHERE bs.key_algorithm IS NOT NULL
ORDER BY bs.database_name,bs.backup_start_date DESC;
GO