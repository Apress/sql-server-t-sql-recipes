/* 18-10 */
Use AdventureWorks2014;
GO
/*
-- In this example, we assume the company's Account number will 
-- be used in multiple tables, and that it will always have a fixed 
-- 14 character length and will never allow NULL values
*/

CREATE TYPE dbo.AccountNBR FROM char(14) NOT NULL;
GO

/* Use the new type in some tables */

Use AdventureWorks2014;
GO
-- The new data type is now used in two different tables
CREATE TABLE dbo.InventoryAccount
(InventoryAccountID int NOT NULL,
InventoryID int NOT NULL,
InventoryAccountNBR AccountNBR);
GO
CREATE TABLE dbo.CustomerAccount
(CustomerAccountID int NOT NULL,
CustomerID int NOT NULL,
CustomerAccountNBR AccountNBR);
GO

/* use a UDT with a proc */
Use AdventureWorks2014;
GO
CREATE PROCEDURE dbo.usp_SEL_CustomerAccount
@CustomerAccountNBR AccountNBR 

AS
SELECT CustomerAccountID, CustomerID, CustomerAccountNBR
FROM dbo.CustomerAccount
WHERE CustomerAccountNBR = CustomerAccountNBR;
GO

/* now to call that proc */
Use AdventureWorks2014;
GO
DECLARE @CustomerAccountNBR AccountNBR 
SET @CustomerAccountNBR = '1294839482';
EXECUTE dbo.usp_SEL_CustomerAccount @CustomerAccountNBR;
GO

/* To see the definition of the UDT */

Use AdventureWorks2014;
GO
EXECUTE sp_help 'dbo.AccountNBR';
GO
