/* 15-17 */

--common query
Use AdventureWorks2014;
GO
SELECT SalesOrderID
  FROM Sales.SalesOrderDetail
  WHERE UnitPrice BETWEEN 150.00 AND 175.00;

/* filtered Index */
Use AdventureWorks2014;
GO
CREATE NONCLUSTERED INDEX NCI_UnitPrice_SalesOrderDetail
  ON Sales.SalesOrderDetail(UnitPrice)
  WHERE UnitPrice >= 150.00 AND UnitPrice <= 175.00;


/* alternate common query */
Use AdventureWorks2014;
GO
SELECT SalesOrderDetailID 
  FROM Sales.SalesOrderDetail 
  WHERE ProductID IN (776, 777) 
  AND OrderQty > 10;

/* filtered index for alternate */
Use AdventureWorks2014;
GO
CREATE NONCLUSTERED INDEX NCI_ProductID_SalesOrderDetail 
  ON Sales.SalesOrderDetail(ProductID,OrderQty) 
  WHERE ProductID IN (776, 777);

