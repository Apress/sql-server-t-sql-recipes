/* 29-5 */
USE master;
GO
DENY CONNECT SQL TO [PETITMOT\Geraud];
GO

USE master;
GO
GRANT CONNECT SQL TO [PETITMOT\Geraud];
GO
