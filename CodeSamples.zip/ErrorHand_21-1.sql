/* 21-1 */
USE master;
GO

IF EXISTS(SELECT 1/0 FROM sys.databases WHERE name = 'Errors')
BEGIN
	DROP DATABASE Errors;
	CREATE DATABASE Errors;
END
ELSE 
BEGIN
	CREATE DATABASE Errors;
END

USE Errors;
GO

CREATE TABLE Works(
number	INT);

INSERT INTO Works
VALUES(1), 
	('A'),
	(3);

SELECT *
FROM Works;

/* and a working version */
USE master;
GO

IF EXISTS(SELECT 1/0 FROM sys.databases WHERE name = 'Errors')
BEGIN
	DROP DATABASE Errors;
	CREATE DATABASE Errors;
END
ELSE 
BEGIN
	CREATE DATABASE Errors;
END
GO

USE Errors;
GO

CREATE TABLE Works(number INT);
GO

INSERT INTO Works
VALUES(1), 
	('A'),
	(3);
GO

INSERT INTO Works
VALUES(1), 
	(2),
	(3);
GO

SELECT *
FROM Works;
