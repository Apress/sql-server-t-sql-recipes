/* 29-14 */
USE TestDB;
GO
EXECUTE sp_helpuser 'Gargouille';
GO
