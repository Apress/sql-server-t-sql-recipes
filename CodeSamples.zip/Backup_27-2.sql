/* 27-2 */
USE master;
GO
BACKUP DATABASE AdventureWorks2014
TO DISK = 'C:\Apress\AdventureWorks2014compress.bak'
WITH COMPRESSION;
GO

USE msdb;
GO
SELECT TOP 2
	bs.database_name
    ,CONVERT(DECIMAL(18,2),backup_size/1024/1024.0) AS backup_mb
    ,CONVERT(DECIMAL(18,2),compressed_backup_size/1024/1024.0) AS compressed_backup_mb
    ,CONVERT(DECIMAL(18,2),backup_size/compressed_backup_size)  AS ratio
	,(1 - CONVERT(DECIMAL(18,2),compressed_backup_size/backup_size))*100 as CompressPercent
FROM msdb.dbo.backupset bs
WHERE bs.database_name = 'Adventureworks2014'
	AND bs.type = 'D'
ORDER BY backup_start_date DESC;
GO
