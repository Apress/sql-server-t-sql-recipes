/* 22-11 */
USE AdventureWorks2014;
GO
EXEC sp_executesql
N'SELECT v.Name ,a.City 
FROM Purchasing.Vendor v 
INNER JOIN [Person].BusinessEntityAddress bea
ON bea.BusinessEntityID = v.BusinessEntityID 
INNER JOIN Person.Address a
ON a.AddressID = bea.AddressID';

/* force join */
USE AdventureWorks2014;
GO
EXEC sp_create_plan_guide
@name = N'Vendor_Query_Loop_to_Merge', 
@stmt = 
N'SELECT v.Name ,a.City 
FROM Purchasing.Vendor v 
INNER JOIN [Person].BusinessEntityAddress bea
ON bea.BusinessEntityID = v.BusinessEntityID 
INNER JOIN Person.Address a
ON a.AddressID = bea.AddressID',
@type = N'SQL', @module_or_batch = NULL, @params = NULL, @hints = N'OPTION (MERGE JOIN)';

/* check the plan guide */
USE AdventureWorks2014;
GO
SELECT name, is_disabled, scope_type_desc, hints 
FROM sys.plan_guides;

/* drop the plan guide */
USE AdventureWorks2014;
GO
EXEC sp_control_plan_guide N'DROP', N'Vendor_Query_Loop_to_Merge';
