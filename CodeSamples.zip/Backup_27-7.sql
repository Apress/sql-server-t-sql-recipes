/* 27-7 */
USE master;
GO

IF EXISTS (SELECT * FROM sys.databases WHERE name = 'AdventureWorks2014_Bak')
BEGIN
DROP DATABASE AdventureWorks2014_Bak;
END
CREATE DATABASE AdventureWorks2014_Bak;
GO

USE AdventureWorks2014_Bak;
GO
CREATE SCHEMA Person
GO

SELECT BusinessEntityID,
	 FirstName,
	 MiddleName,
	 LastName
INTO Person.Person
FROM AdventureWorks2014.Person.Person;
GO

SELECT TOP 6 *
FROM Person.Person
ORDER BY BusinessEntityID;
GO

