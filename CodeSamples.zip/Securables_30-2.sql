/* 30-2 */


USE master;
GO
/*
-- Create recipe login if it doesn't exist 
*/
IF NOT EXISTS (SELECT name FROM sys.server_principals 
    WHERE name = 'Gargouille') 
BEGIN
CREATE LOGIN [Gargouille] 
    WITH PASSWORD=N'test!#l'
    , DEFAULT_DATABASE=[AdventureWorks2014]
    , CHECK_EXPIRATION=OFF, CHECK_POLICY=OFF;
END

--check for the server role
IF NOT EXISTS (SELECT name FROM sys.server_principals 
    WHERE name = 'hdserverstate'
        AND type_desc = 'SERVER_ROLE')
BEGIN
    CREATE SERVER ROLE hdserverstate AUTHORIZATION securityadmin;
    GRANT VIEW SERVER STATE TO hdserverstate;
END

--check for the user
IF NOT EXISTS (SELECT mem.name AS MemberName
    FROM sys.server_role_members rm
        INNER JOIN sys.server_principals sp
            ON rm.role_principal_id = sp.principal_id
        LEFT OUTER JOIN sys.server_principals mem
            ON rm.member_principal_id = mem.principal_id
    WHERE sp.name = 'hdserverstate'
        AND sp.type_desc = 'SERVER_ROLE'
        AND mem.name = 'Gargouille')

BEGIN
    ALTER SERVER ROLE [hdserverstate] ADD MEMBER [Gargouille];
END

/* create / view databases */
USE master;
GO
GRANT CREATE ANY DATABASE, VIEW ANY DATABASE TO [ROIS\Frederic];
GO

/* Deny Shutdown */
USE master;
GO
DENY SHUTDOWN TO [ROIS\Frederic];
GO

/* revoke view server state permission */
USE master;
GO
REVOKE VIEW SERVER STATE FROM hdserverstate
CASCADE;
GO