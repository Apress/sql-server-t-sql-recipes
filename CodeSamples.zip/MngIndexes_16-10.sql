/* 15-9 */
USE AdventureWorks2014;
GO
CREATE NONCLUSTERED INDEX NI_Address_PostalCode 
  ON Person.Address (PostalCode) 
  WITH (SORT_IN_TEMPDB = ON);
