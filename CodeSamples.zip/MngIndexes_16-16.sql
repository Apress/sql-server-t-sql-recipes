/* 15-15 */

Use master;
GO
ALTER DATABASE AdventureWorks2014 
  ADD FILEGROUP FG2;
/* add a new file to the database and the newly created filegroup 
in a folder on the root of C called Apress. */

Use AdventureWorks2014;
GO	
ALTER DATABASE AdventureWorks2012AdventureWorks2014
  ADD FILE
--Please ensure the Apress directory exists or change the path in the FILENAME statement
  ( NAME = AW2,FILENAME = 'c:\Apress\aw2.ndf',SIZE = 1MB ) 
  TO FILEGROUP FG2;

/* create a new index in the newly created filegroup. */

Use AdventureWorks2014;
GO
CREATE INDEX NI_ProductPhoto_ThumnailPhotoFileName 
  ON Production.ProductPhoto (ThumbnailPhotoFileName) 
  ON [FG2];
