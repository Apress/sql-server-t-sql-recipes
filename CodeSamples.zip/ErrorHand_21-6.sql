/* 21-6 */
USE tempdb;
GO

CREATE TABLE Creditor(
CreditorID		INT IDENTITY PRIMARY KEY,
CreditorName	VARCHAR(50)
);
GO

INSERT INTO Creditor
VALUES('You Owe Me'), 
	('You Owe Me More');
GO

SELECT *
FROM Creditor;
GO

/* Create a trigger and test */
USE tempdb;
GO

CREATE TRIGGER Deny_Delete
ON Creditor
FOR DELETE
AS
RAISERROR('Deletions are not permitted',
        16,
	        1)
ROLLBACK TRANSACTION;
GO

DELETE 
FROM Creditor
WHERE CreditorID = 1;
GO

/* solution 2 */
THROW 50000, 'User defined error', 1;

/* improperly declared raiserror */

USE tempdb;
GO

BEGIN TRY
  PRINT 'Outer Try'
    BEGIN TRY
	 	PRINT ERROR_NUMBER() + ' Inner try'
    END TRY
    BEGIN CATCH
        IF ERROR_NUMBER() = 8134
		   PRINT CONVERT(CHAR(5), ERROR_NUMBER()) + ' Inner Catch Divide by zero'
        ELSE 
            BEGIN
            PRINT CONVERT(CHAR(6), ERROR_NUMBER()) + ' '
			 + ERROR_MESSAGE() +
              CONVERT(CHAR(2), ERROR_SEVERITY()) + ' ' +
              CONVERT(CHAR(2), ERROR_STATE()) + ' INITIAL Catch';
           RAISERROR --This THROW is added in the initial CATCH
           END
    END CATCH;
END TRY
BEGIN CATCH
    IF ERROR_NUMBER() = 8134
        PRINT CONVERT(CHAR(5), ERROR_NUMBER()) + ' Outer Catch Divide by zero' 
    ELSE 
        BEGIN
        PRINT CONVERT(CHAR(6), ERROR_NUMBER()) + ' ' + ERROR_MESSAGE() +
              CONVERT(CHAR(2), ERROR_SEVERITY()) + ' ' + 
              CONVERT(CHAR(2), ERROR_STATE()) + ' OUTER Catch';
        RAISERROR
        END
END CATCH;


/* properly defined RAISERROR */
USE tempdb;
GO

BEGIN TRY
  PRINT 'Outer Try'
    BEGIN TRY
	 	PRINT ERROR_NUMBER() + ' Inner try'
    END TRY
    BEGIN CATCH
        DECLARE @error_message AS VARCHAR(500) = ERROR_MESSAGE()
        DECLARE @error_severity AS INT = ERROR_SEVERITY()
        DECLARE @error_state AS INT = ERROR_STATE()

        IF ERROR_NUMBER() = 8134
		   PRINT CONVERT(CHAR(5), ERROR_NUMBER()) + ' Inner Catch Divide by zero'
        ELSE 
            BEGIN
            PRINT CONVERT(CHAR(6), ERROR_NUMBER()) + ' '
			 + ERROR_MESSAGE() +
              CONVERT(CHAR(2), ERROR_SEVERITY()) + ' ' +
              CONVERT(CHAR(2), ERROR_STATE()) + ' INITIAL Catch';
           RAISERROR(@error_message,@error_severity,@error_state); 
           END
    END CATCH;
END TRY
BEGIN CATCH
    IF ERROR_NUMBER() = 8134
        PRINT CONVERT(CHAR(5), ERROR_NUMBER()) + ' Outer Catch Divide by zero' 
    ELSE 
        BEGIN
        PRINT CONVERT(CHAR(6), ERROR_NUMBER()) + ' ' + ERROR_MESSAGE() +
              CONVERT(CHAR(2), ERROR_SEVERITY()) + ' ' + 
              CONVERT(CHAR(2), ERROR_STATE()) + ' OUTER Catch';
        RAISERROR(@error_message,@error_severity,@error_state);

        END
END CATCH;