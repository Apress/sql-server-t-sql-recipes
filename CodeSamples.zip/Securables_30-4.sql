/* 30-4 */
USE master;
GO
/*
-- Create DB for recipe if it doesn't exist
*/
IF NOT EXISTS (SELECT name FROM sys.databases WHERE name = 'TestDB')
BEGIN
CREATE DATABASE TestDB 
END 
GO
/*
Create recipe login if it doesn't exist 
*/
IF NOT EXISTS (SELECT name FROM sys.server_principals 
    WHERE name = 'Phantom') 
BEGIN
CREATE LOGIN [Phantom] 
    WITH PASSWORD=N'test!#23', DEFAULT_DATABASE=[TestDB], CHECK_EXPIRATION=OFF, CHECK_POLICY=OFF 
END;
GO

IF NOT EXISTS (SELECT name FROM sys.server_principals 
    WHERE name = 'Gargouille') 
BEGIN
CREATE LOGIN [Gargouille] 
    WITH PASSWORD=N'test!#l'
    , DEFAULT_DATABASE=[AdventureWorks2014]
    , CHECK_EXPIRATION=OFF, CHECK_POLICY=OFF;
END
GO

USE TestDB;
GO
/*
-- Create db users if they don't already exist
*/
IF NOT EXISTS (SELECT name FROM sys.database_principals 
    WHERE name = 'Gargouille')
BEGIN
CREATE USER Gargouille FROM LOGIN Gargouille 
END;
GO
IF NOT EXISTS (SELECT name FROM sys.database_principals 
    WHERE name = 'Phantom') 
BEGIN
CREATE USER Phantom FROM LOGIN Phantom 
END;
GO

/* Grant Perms to Gargouille */
USE TestDB;
GO
GRANT ALTER ANY ASSEMBLY, ALTER ANY CERTIFICATE TO GARGOUILLE;
GO

/* Deny Perms to Phantom */
USE TestDB;
GO
DENY ALTER ANY DATABASE DDL TRIGGER TO Phantom;
GO

/* Revoke Perms */
USE TestDB;
GO
REVOKE CONNECT FROM Phantom;
GO
