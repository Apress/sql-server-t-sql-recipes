/* 27-5 */
USE msdb;
GO

DECLARE @DBName VARCHAR(128) = 'AdventureWorks2014'

SELECT d.name,ca.backup_finish_date AS LastFullBackup
		,bs.BACKUP_finish_date AS LastLogBackup
	FROM sys.databases d
		LEFT OUTER JOIN msdb.dbo.backupset bs
			ON d.name = bs.database_name
			AND bs.TYPE = 'l'
		OUTER APPLY (SELECT TOP 1 database_name,backup_finish_date
						FROM msdb.dbo.backupset
						WHERE database_name = d.name
							AND type = 'D'
						ORDER BY backup_finish_date DESC) ca
	WHERE d.recovery_model_desc <> 'simple'
		AND bs.database_name IS NULL
		AND d.name = @DBName;
GO

/* whoops we have no log backup so take a log backup */
USE master;
GO

BACKUP LOG AdventureWorks2014
TO DISK = 'C:\Apress\AdventureWorks2014.trn';


/* some additional checks */
USE master;
GO

CREATE DATABASE Logging;
GO

ALTER DATABASE Logging
SET RECOVERY SIMPLE;
GO

USE Logging;
GO

CREATE TABLE FillErUp(
RowInfo	CHAR(150)
);
GO

/* check catalog views */
USE master;
GO
DECLARE @DBName VARCHAR(128) = 'Logging';

SELECT d.name as DBName, mf.size, d.recovery_model_desc, d.log_reuse_wait_desc
	FROM sys.master_files mf
		INNER JOIN sys.databases d
			ON d.database_id = mf.database_id
	WHERE d.name = @DBName
		AND mf.type_desc = 'LOG';
GO

USE Logging;
GO
SET NOCOUNT ON;
DECLARE @count INT = 10000
WHILE @count > 0
BEGIN
   INSERT INTO FillErUp (RowInfo)
   SELECT 'This is row # ' + CONVERT(CHAR(4), @count)
   SET @count -= 1
END;
GO

CHECKPOINT;
GO

/* check catalog views */
USE master;
GO
DECLARE @DBName VARCHAR(128) = 'Logging';

SELECT d.name as DBName, mf.size, d.recovery_model_desc, d.log_reuse_wait_desc
	FROM sys.master_files mf
		INNER JOIN sys.databases d
			ON d.database_id = mf.database_id
	WHERE d.name = @DBName
		AND mf.type_desc = 'LOG';

/* long running transaction */
USE Logging;
GO

BEGIN TRAN

DECLARE @count INT = 10000
WHILE @count > 0
BEGIN
   INSERT INTO FillErUp
   SELECT 'This is row # ' + CONVERT(CHAR(4), @count)
   SET @count -= 1
END;
GO

USE master;
GO
DECLARE @DBName VARCHAR(128) = 'Logging';

SELECT d.name as DBName, mf.size, d.recovery_model_desc, d.log_reuse_wait_desc
	FROM sys.master_files mf
		INNER JOIN sys.databases d
			ON d.database_id = mf.database_id
	WHERE d.name = @DBName
		AND mf.type_desc = 'LOG';

DBCC SQLPERF(LOGSPACE);
GO

USE Logging;
GO

COMMIT TRAN;
GO
CHECKPOINT;
GO

USE master;
GO
DECLARE @DBName VARCHAR(128) = 'Logging';

SELECT d.name as DBName, mf.size, d.recovery_model_desc, d.log_reuse_wait_desc
	FROM sys.master_files mf
		INNER JOIN sys.databases d
			ON d.database_id = mf.database_id
	WHERE d.name = @DBName
		AND mf.type_desc = 'LOG';

DBCC SQLPERF(LOGSPACE);
GO

/* full recovery */
USE master;
GO

--Create the Logging database
IF EXISTS (SELECT * FROM sys.databases WHERE name = 'Logging')
BEGIN
DROP DATABASE Logging;
END
GO

CREATE DATABASE Logging
ON PRIMARY
( NAME = N'Logging', FILENAME = N'C:\APRESS\Logging.mdf' , SIZE = 4096KB  )
 LOG ON 
( NAME = N'Logging_log', FILENAME = N'C:\APRESS\Logging_log.ldf' , SIZE = 512KB );
GO

ALTER DATABASE Logging
SET RECOVERY FULL;
GO

ALTER DATABASE Logging 
MODIFY FILE
    (NAME = Logging_log,
    SIZE = 520KB);
GO

--Size is 101
USE master;
GO
DECLARE @DBName VARCHAR(128) = 'Logging';

SELECT d.name as DBName, mf.size, d.recovery_model_desc, d.log_reuse_wait_desc
	FROM sys.master_files mf
		INNER JOIN sys.databases d
			ON d.database_id = mf.database_id
	WHERE d.name = @DBName
		AND mf.type_desc = 'LOG';
GO

USE Logging;
GO
SELECT TOP 10000
        RowInfo = 'This is row # ' + CONVERT(CHAR(5)
		    , ROW_NUMBER() OVER (PARTITION BY t1.autoval ORDER BY (SELECT NULL)))
   INTO dbo.FillErUp
   FROM master.dbo.syscolumns t1,
        master.dbo.syscolumns t2;
GO

CHECKPOINT;
GO

USE master;
GO
DECLARE @DBName VARCHAR(128) = 'Logging';

SELECT d.name as DBName, mf.size, d.recovery_model_desc, d.log_reuse_wait_desc
	FROM sys.master_files mf
		INNER JOIN sys.databases d
			ON d.database_id = mf.database_id
	WHERE d.name = @DBName
		AND mf.type_desc = 'LOG';
GO

USE master;
GO

BACKUP DATABASE Logging
TO DISK =  'C:\Apress\Logging.bak';
GO

USE Logging;
GO
INSERT INTO dbo.FillErUp
SELECT TOP 10000
        RowInfo = 'This is row # ' + CONVERT(CHAR(5)
		    , ROW_NUMBER() OVER (PARTITION BY t1.autoval ORDER BY (SELECT NULL)))
   FROM master.dbo.syscolumns t1,
        master.dbo.syscolumns t2;
GO

CHECKPOINT;
GO

USE master;
GO
DECLARE @DBName VARCHAR(128) = 'Logging';

SELECT d.name as DBName, mf.size, d.recovery_model_desc, d.log_reuse_wait_desc
	FROM sys.master_files mf
		INNER JOIN sys.databases d
			ON d.database_id = mf.database_id
	WHERE d.name = @DBName
		AND mf.type_desc = 'LOG';
GO

/* bulk logged */

USE master;
GO

IF EXISTS (SELECT * FROM sys.databases WHERE name = 'Logging')
BEGIN
DROP DATABASE Logging;
END
GO

CREATE DATABASE Logging;
GO

ALTER DATABASE Logging
SET RECOVERY BULK_LOGGED;
GO

BACKUP DATABASE Logging
TO DISK =  'C:\Apress\Logging_bulk.bak';
GO

USE master;
GO
DECLARE @DBName VARCHAR(128) = 'Logging';

SELECT d.name as DBName, mf.size, d.recovery_model_desc, d.log_reuse_wait_desc
	FROM sys.master_files mf
		INNER JOIN sys.databases d
			ON d.database_id = mf.database_id
	WHERE d.name = @DBName
		AND mf.type_desc = 'LOG';
GO

USE Logging;
GO

SELECT *
	INTO PurchaseOrderDetail
	FROM AdventureWorks2014.Purchasing.PurchaseOrderDetail

USE master;
GO
DECLARE @DBName VARCHAR(128) = 'Logging';

SELECT d.name as DBName, mf.size, d.recovery_model_desc, d.log_reuse_wait_desc
	FROM sys.master_files mf
		INNER JOIN sys.databases d
			ON d.database_id = mf.database_id
	WHERE d.name = @DBName
		AND mf.type_desc = 'LOG';
GO