/* 15-16 */
Use AdventureWorks2014;
GO
CREATE NONCLUSTERED INDEX NI_WebSiteHits_WebSitePage 
  ON Sales.WebSiteHits (WebSitePage) 
  ON [HitDateRangeScheme] (HitDate);
