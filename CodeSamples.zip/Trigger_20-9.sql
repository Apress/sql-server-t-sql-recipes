/* 20-9 */

USE master;
GO

ALTER TRIGGER trg_logon_attempt ON ALL SERVER
 WITH EXECUTE AS 'sa'
       FOR LOGON
AS
       BEGIN
             IF ORIGINAL_LOGIN() = 'nightworker'
                AND DATEPART(hh, GETDATE()) BETWEEN 7 AND 18 
                BEGIN
                      --ROLLBACK ;
                      INSERT    ExampleAuditDB.dbo.RestrictedLogonAttempt
                                (LoginName, AttemptDate)
                      VALUES    (ORIGINAL_LOGIN(), GETDATE()) ;
                END 
       END 
GO
