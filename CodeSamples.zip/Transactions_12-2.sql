/* 12-2 */
USE AdventureWorks2014;
GO
BEGIN TRANSACTION
DELETE Production.ProductProductPhoto 
WHERE ProductID = 317;

DBCC OPENTRAN('AdventureWorks2014');

ROLLBACK TRANSACTION;
GO 
