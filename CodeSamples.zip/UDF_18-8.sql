/* 18-8 */
Use AdventureWorks2014;
GO
CREATE FUNCTION dbo.udf_SEL_SalesQuota ( @BusinessEntityID int, @ShowHistory bit ) 
RETURNS @SalesQuota TABLE (BusinessEntityID int, QuotaDate datetime, SalesQuota money)

AS 
BEGIN
INSERT Into @SalesQuota(BusinessEntityID, QuotaDate, SalesQuota)
      SELECT BusinessEntityID, ModifiedDate, SalesQuota
      FROM Sales.SalesPerson
      WHERE BusinessEntityID = @BusinessEntityID;
IF @ShowHistory = 1 
BEGIN
INSERT Into @SalesQuota(BusinessEntityID, QuotaDate, SalesQuota)
      SELECT BusinessEntityID, QuotaDate, SalesQuota
      FROM Sales.SalesPersonQuotaHistory
      WHERE BusinessEntityID = @BusinessEntityID;
END
RETURN 
END
GO

/* Test the UDF */

Use AdventureWorks2014;
GO

SELECT BusinessEntityID, QuotaDate, SalesQuota 
      FROM dbo.udf_SEL_SalesQuota (275,0);


Use AdventureWorks2014;
GO

SELECT BusinessEntityID, QuotaDate, SalesQuota 
      FROM dbo.udf_SEL_SalesQuota (275,1);
