/* 29-16 */
USE TestDB;
GO
DROP USER FeeDauphin;
GO
