/* 24-2 */
-- Rebuild a specific index
USE AdventureWorks2014;
GO
ALTER INDEX PK_ShipMethod_ShipMethodID ON Purchasing.ShipMethod REBUILD;

-- Rebuild all indexes on a specific table
USE AdventureWorks2014;
GO
ALTER INDEX ALL
ON Purchasing.PurchaseOrderHeader REBUILD;

-- Rebuild an index, while keeping it available -- for queries (requires Enterprise Edition)
USE AdventureWorks2014;
GO
ALTER INDEX PK_ProductReview_ProductReviewID 
ON Production.ProductReview REBUILD WITH (ONLINE = ON);

-- Rebuild an index, using a new fill factor and -- sorting in tempdb
USE AdventureWorks2014;
GO
ALTER INDEX PK_TransactionHistory_TransactionID 
ON Production.TransactionHistory REBUILD WITH (FILLFACTOR = 75, SORT_IN_TEMPDB = ON);

-- Rebuild an index with page-level data compression enabled 
USE AdventureWorks2014;
GO
ALTER INDEX PK_ShipMethod_ShipMethodID 
ON Purchasing.ShipMethod REBUILD WITH (DATA_COMPRESSION = PAGE);

-- Rebuild an index with low priority wait
USE AdventureWorks2014;
GO
ALTER INDEX PK_ShipMethod_ShipMethodID 
ON Purchasing.ShipMethod 
REBUILD WITH (ONLINE = ON (
    WAIT_AT_LOW_PRIORITY ( MAX_DURATION = 2 MINUTES, ABORT_AFTER_WAIT = SELF ) 
    ));
