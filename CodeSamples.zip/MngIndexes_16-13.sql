/* 15-12 */
USE AdventureWorks2014;
GO
ALTER TABLE HumanResources.TerminationReason 
  ADD LegalDescription varchar(max);
Go
DROP INDEX HumanResources.TerminationReason.NI_TerminationReason_TerminationReason_DepartmentID;
Go
CREATE NONCLUSTERED INDEX NI_TerminationReason_TerminationReason_DepartmentID 
  ON HumanResources.TerminationReason (TerminationReason, DepartmentID) 
  INCLUDE (LegalDescription);
