/* 15-5 */
USE AdventureWorks2014;
GO
EXEC sp_helpindex 'HumanResources.Employee';

/* more in depth using catalog views */
USE AdventureWorks2014;
GO
SELECT index_name = SUBSTRING(name, 1,30) ,
		allow_row_locks,
		allow_page_locks,
		is_disabled,
		fill_factor,
		has_filter 
	FROM sys.indexes 
	WHERE object_id = OBJECT_ID('HumanResources.Employee');
