/* 28-10 */
USE master;
GO
SELECT c.name,c.start_date,c.pvt_key_encryption_type_desc,c.pvt_key_last_backup_date
	FROM sys.certificates c
	WHERE name = 'AW2014BackupCert';
GO

DROP CERTIFICATE AW2014BackupCert;
GO

CREATE CERTIFICATE AW2014BackupCert 
FROM FILE ='c:\Apress\AW2014BackupCert.cer'
WITH PRIVATE KEY(FILE='C:\Apress\AW2014BackupCertKey.bak'
    ,DECRYPTION BY PASSWORD='SQL2014Rocks');
GO

SELECT c.name,c.start_date,c.pvt_key_encryption_type_desc,c.pvt_key_last_backup_date
	FROM sys.certificates c
	WHERE name = 'AW2014BackupCert';