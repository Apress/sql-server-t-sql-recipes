/* 20-6 */
USE AdventureWorks2014;
GO

CREATE TABLE dbo.DDLAudit
              (
              EventData XML NOT NULL,
              AttemptDate DATETIME NOT NULL
                          DEFAULT GETDATE(),
              DBUser CHAR(50) NOT NULL
              ) ;
GO

/* Create DB DDL trigger to track index operations and 
insert the event data to the audit table. */

CREATE TRIGGER db_trg_INDEXChanges ON DATABASE
       FOR CREATE_INDEX, ALTER_INDEX, DROP_INDEX
AS
       SET NOCOUNT ON ;
       INSERT INTO dbo.DDLAudit
                (EventData, DBUser)
       VALUES   (EVENTDATA(), USER) ;
GO

/* Create an index */
CREATE NONCLUSTERED INDEX ni_DDLAudit_DBUser 
	ON dbo.DDLAudit(DBUser) ;
GO

SELECT  EventData
FROM    dbo.DDLAudit;
 