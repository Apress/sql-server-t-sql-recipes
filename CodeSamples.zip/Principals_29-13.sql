/* 29-13 */
USE master;
GO
IF NOT EXISTS (SELECT name FROM sys.databases
    WHERE name = 'TestDB')
BEGIN
    CREATE DATABASE TestDB
END 
GO
USE TestDB;
GO
CREATE USER Gargouille;
GO

/* from a login */
USE TestDB;
GO
CREATE SCHEMA HumanResources;
GO
CREATE USER Bayard
FOR LOGIN [PETITMOT\Bayard]
WITH DEFAULT_SCHEMA = HumanResources;
GO
