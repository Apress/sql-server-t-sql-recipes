/* 27-16 */
USE master;
GO

CREATE CREDENTIAL SQL2014 
WITH IDENTITY= 'Recipes2014'
, SECRET = 'SQL2014Rocks'

BACKUP DATABASE AdventureWorks2014
TO URL = N'https://Recipes2014.blob.core.windows.net/backuptest/AW2014_blob.bak'
WITH
  CREDENTIAL = 'SQL2014'
  ,COMPRESSION
  ,STATS = 10
GO