/* 29-21 */
USE AdventureWorks2014;
GO
CREATE APPLICATION ROLE DataWareHouseApp 
WITH PASSWORD = 'mywarehousel23!', DEFAULT_SCHEMA = dbo;
GO

-- Now grant this application role permissions
USE AdventureWorks2014;
GO
GRANT SELECT ON Sales.vSalesPersonSalesByFiscalYears
TO DataWareHouseApp;
GO

USE AdventureWorks2014;
GO
EXECUTE sp_setapprole 'DataWareHouseApp', -- App role name 
    'mywarehousel23!' -- Password
	;
GO
-- This query Works
SELECT COUNT(*)
FROM Sales.vSalesPersonSalesByFiscalYears;
-- This query Doesn't work 
SELECT COUNT(*) FROM HumanResources.vJobCandidate;
GO

revert

/* make a quick change */

USE AdventureWorks2014;
GO
ALTER APPLICATION ROLE DataWareHouseApp
WITH NAME = DW_App, PASSWORD = 'newsecret!123';
GO

/* cleanup */
USE AdventureWorks2014;
GO
DROP APPLICATION ROLE DW_App;
GO

