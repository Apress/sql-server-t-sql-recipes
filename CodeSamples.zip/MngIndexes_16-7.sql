/* 15-6 */
USE AdventureWorks2014;
GO
ALTER INDEX UNI_TerminationReason 
  ON HumanResources.TerminationReason DISABLE;
