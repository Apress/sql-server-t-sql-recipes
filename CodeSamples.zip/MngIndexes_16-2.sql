/* 16-2 */
/* Create a New Table and Index at same time*/
USE AdventureWorks2014;
GO
IF EXISTS (Select 1/0 from sys.objects where name = 'TerminationReason' and SCHEMA_NAME(schema_id) = 'HumanResources')
BEGIN
	DROP TABLE HumanResources.TerminationReason;
END
CREATE TABLE HumanResources.TerminationReason(
  TerminationReasonID smallint IDENTITY(1,1) NOT NULL, 
  TerminationReason varchar(50) NOT NULL, 
  DepartmentID smallint NOT NULL INDEX NCI_TerminationReason_DepartmentID NONCLUSTERED, 
  CONSTRAINT FK_TerminationReason_DepartmentID FOREIGN KEY (DepartmentID) 
REFERENCES HumanResources.Department(DepartmentID) 
	);
/* Create a Primary Key and Clustered Index */
USE AdventureWorks2014;
GO
ALTER TABLE HumanResources.TerminationReason
ADD CONSTRAINT PK_TerminationReason PRIMARY KEY CLUSTERED (TerminationReasonID);


/* Variation on the Inline Index Creation */
USE AdventureWorks2014;
GO
IF EXISTS (Select 1/0 from sys.objects where name = 'TerminationReason' and SCHEMA_NAME(schema_id) = 'HumanResources')
BEGIN
	DROP TABLE HumanResources.TerminationReason;
END

CREATE TABLE HumanResources.TerminationReason(
  TerminationReasonID smallint IDENTITY(1,1) NOT NULL, 
  TerminationReason varchar(50) NOT NULL, 
  DepartmentID smallint NOT NULL,
  INDEX NCI_TerminationReason_DepartmentID NONCLUSTERED (DepartmentID), 
  CONSTRAINT FK_TerminationReason_DepartmentID FOREIGN KEY (DepartmentID) 
REFERENCES HumanResources.Department(DepartmentID) 
	);

/* Create a Primary Key and Clustered Index */
USE AdventureWorks2014;
GO
ALTER TABLE HumanResources.TerminationReason
ADD CONSTRAINT PK_TerminationReason PRIMARY KEY CLUSTERED (TerminationReasonID);

