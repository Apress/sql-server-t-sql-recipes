/* 29-11 */
USE master;
GO
CREATE LOGIN Gargouille WITH PASSWORD = 'De3pd@rkCave';
GO
ALTER SERVER ROLE diskadmin
    ADD MEMBER [Gargouille];
GO

USE master;
GO
ALTER SERVER ROLE diskadmin
    DROP MEMBER [Gargouille];
GO
