/* 20-4 */
USE AdventureWorks2014;
GO
CREATE TRIGGER HumanResources.trg_U_Department ON HumanResources.Department
       AFTER UPDATE
AS
       IF UPDATE(GroupName) 
          BEGIN
                PRINT 'Updates to GroupName require DBA involvement.' ;
                ROLLBACK  ;
          END 
GO

/* Attempt an Update */
UPDATE  HumanResources.Department
SET     GroupName = 'Research and Development'
WHERE   DepartmentID = 10 ;
