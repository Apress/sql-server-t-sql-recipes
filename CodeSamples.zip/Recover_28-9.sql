/* 28-9 */
USE master;
GO
RESTORE DATABASE AdventureWorks2014
FROM URL = N'https://Recipes2014.blob.core.windows.net/backuptest/AW2014_blob.bak'
WITH
  CREDENTIAL = 'SQL2014'
  ,BUFFERCOUNT = 75
  ,STATS = 10
  ,REPLACE
GO
