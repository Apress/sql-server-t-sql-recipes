/* 29-20 */
USE TestDB;
GO
EXECUTE sp_helprole;
GO

USE AdventureWorks2014;
GO
CREATE ROLE HR_ReportSpecialist AUTHORIZATION db_owner;
GO

Use AdventureWorks2014;
GO
GRANT SELECT ON HumanResources.Employee TO HR_ReportSpecialist;
GO

USE AdventureWorks2014;
GO
If not exists (select name from sys.server_principals
				where name ='Gargouille')
Begin
CREATE LOGIN Gargouille
WITH PASSWORD = 'BigTr3e',
DEFAULT_DATABASE = AdventureWorks2014;
End
GO
If not exists (select name from sys.database_principals
				where name = 'Gargouille')
Begin
CREATE USER Gargouille;
END
GO
ALTER ROLE HR_ReportSpecialist
ADD MEMBER Gargouille;
GO

/* make a quick change */
USE AdventureWorks2014;
GO
ALTER ROLE HR_ReportSpecialist WITH NAME = HumanResources_RS;
GO

/* drop role */
USE AdventureWorks2014;
GO
DROP ROLE HumanResources_RS;
GO

USE AdventureWorks2014;
GO
ALTER ROLE HumanResources_RS
DROP MEMBER Gargouille;
GO
DROP ROLE HumanResources_RS;
GO
