/* 15-3 */

USE AdventureWorks2014;
GO
CREATE NONCLUSTERED INDEX NI_TerminationReason_TerminationReason_DepartmentID 
  ON HumanResources.TerminationReason(TerminationReason, DepartmentID);
