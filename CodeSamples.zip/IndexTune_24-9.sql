/* 24-9 */
USE AdventureWorks2014;
GO
EXECUTE sp_createstats;
GO
