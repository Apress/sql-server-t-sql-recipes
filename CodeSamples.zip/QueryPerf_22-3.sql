/* 22-3 */
USE AdventureWorks2014;
GO
SET STATISTICS IO ON;
GO
SELECT t.Name TerritoryNM,
SUM(TotalDue) TotalDue 
FROM Sales.SalesOrderHeader h 
INNER JOIN Sales.SalesTerritory t 
ON h.TerritoryID = t.TerritoryID 
WHERE OrderDate BETWEEN '1/1/2014' AND '12/31/2014' 
GROUP BY t.Name 
ORDER BY t.Name
SET STATISTICS IO OFF;
GO

/* try with statistics time now */
USE AdventureWorks2014;
GO
SET STATISTICS TIME ON;
GO
SELECT t.Name TerritoryNM,
SUM(TotalDue) TotalDue 
FROM Sales.SalesOrderHeader h 
INNER JOIN Sales.SalesTerritory t 
ON h.TerritoryID = t.TerritoryID 
WHERE OrderDate BETWEEN '1/1/2014' AND '12/31/2014' 
GROUP BY t.Name 
ORDER BY t.Name
SET STATISTICS TIME OFF;
GO
