/* 29-10 */
USE master;
GO
DROP LOGIN HyBrasil;
GO
