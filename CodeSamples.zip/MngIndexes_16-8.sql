/* 15-7 */
USE AdventureWorks2014;
GO
DROP INDEX UNI_TerminationReason
ON HumanResources.TerminationReason;
GO
