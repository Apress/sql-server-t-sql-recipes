/* 21-2 */
USE master;
GO
SELECT sl.alias as LangAlias,
	   message_id,
	   severity,
	   text
FROM sys.messages m
	INNER JOIN sys.syslanguages sl
		ON m.language_id = sl.msglangid
WHERE sl.name = 'us_english'
ORDER BY m.message_id, m.severity;
GO

