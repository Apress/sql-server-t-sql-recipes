/* 16-20 */
/* Create a Clustered ColumnStore Index */
USE AdventureWorks2014;
GO
IF EXISTS (Select 1/0 from sys.objects where name = 'TerminationReason' and SCHEMA_NAME(schema_id) = 'HumanResources')
BEGIN
	DROP TABLE HumanResources.TerminationReason;
END

CREATE TABLE HumanResources.TerminationReason(
  TerminationReasonID smallint IDENTITY(1,1) NOT NULL, 
  TerminationReason varchar(50) NOT NULL, 
  DepartmentID smallint NOT NULL,
  INDEX NCI_TerminationReason_DepartmentID NONCLUSTERED (DepartmentID)
	);
GO

DROP INDEX NCI_TerminationReason_DepartmentID ON HumanResources.TerminationReason;
GO

CREATE CLUSTERED COLUMNSTORE INDEX PK_TerminationReason ON HumanResources.TerminationReason;
GO

