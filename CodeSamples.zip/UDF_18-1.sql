/* 18-1 */
Use AdventureWorks2014;
GO

Create Function dbo.udf_CheckForSQLInjection (@TSQLString varchar(max))
Returns bit

AS

BEGIN

DECLARE  @IsSuspect  bit;

--  UDF  assumes  string  will  be  left  padded  with  a  single  space
SET  @TSQLString  =  '  '  +  @TSQLString;

IF        (PATINDEX('%  xp_%'  ,  @TSQLString  )  <>  0 OR
      PATINDEX('%  sp_%'  ,  @TSQLString  )  <>  0      OR
      PATINDEX('%  DROP %'  ,  @TSQLString  )  <>  0   OR
      PATINDEX('%  GO %'  ,  @TSQLString  )  <>  0  OR
      PATINDEX('%  INSERT %'  ,  @TSQLString  )  <>  0 OR
      PATINDEX('%  UPDATE %'  ,  @TSQLString  )  <>  0 OR
      PATINDEX('%  DBCC %'  ,  @TSQLString  )  <>  0   OR
      PATINDEX('%  SHUTDOWN %'  ,  @TSQLString  )<>  0  OR
      PATINDEX('%  ALTER %'  ,  @TSQLString  )<>  0    OR
      PATINDEX('%  CREATE %'  ,  @TSQLString  )  <>  0 OR
      PATINDEX('%;%'  ,  @TSQLString  )<>  0  OR
      PATINDEX('%  EXECUTE %'  ,  @TSQLString  )<>  0  OR
      PATINDEX('%  BREAK %'  ,  @TSQLString  )<>  0    OR
      PATINDEX('%  BEGIN %'  ,  @TSQLString  )<>  0    OR
      PATINDEX('%  CHECKPOINT %'  ,  @TSQLString  )<>  0  OR
      PATINDEX('%  BREAK %'  ,  @TSQLString  )<>  0    OR
      PATINDEX('%  COMMIT %'  ,  @TSQLString  )<>  0   OR
      PATINDEX('%  TRANSACTION %'  ,  @TSQLString  )<>  0  OR
      PATINDEX('%  CURSOR %'  ,  @TSQLString  )<>  0   OR
      PATINDEX('%  GRANT %'  ,  @TSQLString  )<>  0    OR
      PATINDEX('%  DENY %'  ,  @TSQLString  )<>  0     OR
      PATINDEX('%  ESCAPE %'  ,  @TSQLString  )<>  0   OR
      PATINDEX('%  WHILE %'  ,  @TSQLString  )<>  0    OR
      PATINDEX('%  OPENDATASOURCE %'  ,  @TSQLString  )<>  0  OR
      PATINDEX('%  OPENQUERY %'  ,  @TSQLString  )<>  0  OR
      PATINDEX('%  OPENROWSET %'  ,  @TSQLString  )<>  0      OR
      PATINDEX('%  EXEC %'  ,  @TSQLString  )<>  0)

BEGIN
      SELECT  @IsSuspect  =     1;
END
ELSE
BEGIN
      SELECT  @IsSuspect  =     0;
END
      RETURN  (@IsSuspect);
END

GO

/* Evaluate the Function with some different strings */

Use AdventureWorks2014;
GO
SELECT dbo.udf_CheckForSQLInjection ('SELECT * FROM HumanResources.Department');

Use AdventureWorks2014;
GO
SELECT dbo.udf_CheckForSQLInjection (';SHUTDOWN');

Use AdventureWorks2014;
GO
SELECT dbo.udf_CheckForSQLInjection ('DROP HumanResources.Department');

GO

/* Create a UCase function */
Use AdventureWorks2014;
GO
CREATE FUNCTION dbo.udf_ProperCase(@UnCased varchar(max))
RETURNS varchar(max)
AS
BEGIN
SET @UnCased = LOWER(@UnCased)
DECLARE @C int
SET @C = ASCII('a')
WHILE @C <= ASCII('z') BEGIN
SET @UnCased = REPLACE( @UnCased, ' ' + CHAR(@C), ' ' + CHAR(@C-32)) SET @C = @C + 1
END
SET @UnCased = CHAR(ASCII(LEFT(@UnCased, 1))-32) + RIGHT(@UnCased, LEN(@UnCased)-1)

RETURN @UnCased END
GO

/* Let's test it out */
SELECT dbo.udf_ProperCase(DocumentSummary)
FROM Production.Document
WHERE FileName = 'Installing Replacement Pedals.doc'
