/* 27-17 */
USE master;
GO

BACKUP DATABASE AdventureWorks2014
TO DISK = 'C:\Apress\AdventureWorks2014_01.bak'
, DISK = 'C:\Apress\AdventureWorks2014_02.bak'
WITH COMPRESSION
	,STATS = 5