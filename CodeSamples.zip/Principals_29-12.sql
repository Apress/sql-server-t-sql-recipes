/* 29-12 */
USE master;
GO
SELECT name
FROM sys.server_principals
WHERE type_desc = 'SERVER_ROLE';
GO

USE master;
GO
EXECUTE sp_helpsrvrole;
GO

EXECUTE sp_helpsrvrolemember 'sysadmin';

USE master;
GO
SELECT SUSER_NAME(SR.role_principal_id) AS ServerRole
        , SUSER_NAME(SR.member_principal_id) AS PrincipalName
        , SP.sid
    FROM sys.server_role_members SR
    INNER JOIN sys.server_principals SP
        ON SR.member_principal_id = SP.principal_id
    WHERE SUSER_NAME(SR.role_principal_id) = 'sysadmin';
GO
