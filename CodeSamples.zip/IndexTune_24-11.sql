/* 24-11 */
USE AdventureWorks2014;
GO
DBCC SHOW_STATISTICS ( 'Sales.Customer' , AK_Customer_AccountNumber);

