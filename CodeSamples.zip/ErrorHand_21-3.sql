/* 21-3 */
USE tempdb;
GO

BEGIN TRY
 SELECT 1/0  --This will raise a divide by zero error if not handled
END TRY
BEGIN CATCH
END CATCH;
GO

/* return structured error information */
USE tempdb;
GO
BEGIN TRY
  SELECT 1/0 --This will raise a divide by zero error if not handled
END TRY
BEGIN CATCH
  SELECT ERROR_LINE() AS 'Line',
		 ERROR_MESSAGE() AS 'Message',
		 ERROR_NUMBER() AS 'Number',
		 ERROR_PROCEDURE() AS 'Procedure',
		 ERROR_SEVERITY() AS 'Severity',
		 ERROR_STATE() AS 'State'
END CATCH;

/* poor syntax errors */
USE tempdb;
GO

BEGIN TRY
  SELCT
END TRY
BEGIN CATCH
END CATCH;
GO

/* binding errors */
USE tempdb;
GO

BEGIN TRY
  SELECT NoSuchTable
END TRY
BEGIN CATCH
END CATCH;
GO

/* informational messages */
USE tempdb;
GO

BEGIN TRY
  RAISERROR('Information ONLY', 10, 1)
END TRY
BEGIN CATCH
END CATCH;
GO
