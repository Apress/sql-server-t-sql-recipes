/* 12-7 */

USE AdventureWorks2014;
GO
BEGIN TRAN
UPDATE Production.ProductInventory 
SET Quantity = 400 
WHERE ProductID = 1 AND LocationID = 1;

/* Next, in a second query editor window, the following query is executed. */
USE AdventureWorks2014;
GO
BEGIN TRAN
UPDATE Production.ProductInventory 
SET Quantity = 406 
WHERE ProductID = 1 AND LocationID = 1;

/*Now in a third query editor window, I�ll execute the followingthis next query. */
SELECT blocking_session_id, wait_duration_ms, session_id
FROM sys.dm_os_waiting_tasks
WHERE blocking_session_id IS NOT NULL;
GO

SELECT t.text
FROM sys.dm_exec_connections c
CROSS APPLY sys.dm_exec_sql_text (c.most_recent_sql_handle) t
WHERE c.session_id = 53; --use the blocking_session_id from the previous query
GO
