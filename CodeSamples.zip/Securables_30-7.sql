/* 30-7 */
/* see schemas that exist in the database */

USE AdventureWorks2014;
GO
SELECT s.name SchemaName, d.name SchemaOwnerName
FROM sys.schemas s
INNER JOIN sys.database_principals d 
ON s.principal_id= d.principal_id 
ORDER BY s.name;
GO

--grant take ownership
USE AdventureWorks2014;
GO
GRANT TAKE OWNERSHIP ON SCHEMA ::Person TO TestUser;
GO

--grant more permissions
USE AdventureWorks2014;
GO
GRANT ALTER, EXECUTE, SELECT ON SCHEMA ::Production TO TestUser 
WITH GRANT OPTION;
GO

--deny some permissions
USE AdventureWorks2014;
GO
DENY INSERT, UPDATE, DELETE ON SCHEMA ::Production TO TestUser;
GO

--revoke permissions
USE AdventureWorks2014;
GO
REVOKE ALTER, SELECT ON SCHEMA ::Production TO TestUser CASCADE;
GO
