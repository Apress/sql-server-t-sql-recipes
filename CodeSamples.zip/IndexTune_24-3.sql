/* 24-3 */
-- Reorganize a specific index
USE AdventureWorks2014;
GO
ALTER INDEX PK_TransactionHistory_TransactionID
ON Production.TransactionHistory
REORGANIZE;

-- Reorganize all indexes for a table
-- Compact large object data types
USE AdventureWorks2014;
GO
ALTER INDEX ALL
ON HumanResources.JobCandidate
REORGANIZE
WITH (LOB_COMPACTION = ON);
