/* 27-3 */
USE master;
GO
BACKUP DATABASE AdventureWorks2014 
TO  DISK = 'C:\Apress\AdventureWorks2014check.bak' 
WITH CHECKSUM;

/* restore validation */
USE master;
GO
RESTORE VERIFYONLY 
FROM  DISK = 'C:\Apress\AdventureWorks2014check.bak'
WITH CHECKSUM;

/* continue after error */
USE master;
GO
BACKUP DATABASE AdventureWorks2014 
TO  DISK = 'C:\Apress\AdventureWorks2014checkcon.bak' 
WITH CHECKSUM, CONTINUE_AFTER_ERROR;
