/* 29-4 */
USE master;
GO
-- Windows Group login
DROP LOGIN [PETITMOT\Contenu];
-- Windows user login 
DROP LOGIN [PETITMOT\JeanLouis];
GO
