/* 30-17 */
/* disable the audit spec */
USE master;
GO
ALTER SERVER AUDIT SPECIFICATION [TroisMots_Server_Audit_Spec] WITH (STATE = OFF);
GO

/* Drop an audit item */
USE master;
GO
ALTER SERVER AUDIT SPECIFICATION [TroisMots_Server_Audit_Spec] 
DROP (BACKUP_RESTORE_GROUP);
GO

/* add an audit group */
USE master;
GO
ALTER SERVER AUDIT SPECIFICATION [TroisMots_Server_Audit_Spec] 
ADD (LOGIN_CHANGE_PASSWORD_GROUP);
GO

/* enable audit spec */
USE master;
GO
ALTER SERVER AUDIT SPECIFICATION [TroisMots_Server_Audit_Spec] 
WITH (STATE = ON);
GO

/* disable db audit spec */
USE AdventureWorks2014;
GO
ALTER DATABASE AUDIT SPECIFICATION [AdventureWorks2014_DB_Spec] 
WITH (STATE = OFF);
GO

/* drop an event */
USE AdventureWorks2014;
GO
ALTER DATABASE AUDIT SPECIFICATION [AdventureWorks2014_DB_Spec] 
DROP (INSERT ON [HumanResources].[Department] BY public);
GO

/* add audit event */
USE AdventureWorks2014;
GO
ALTER DATABASE AUDIT SPECIFICATION [AdventureWorks2014_DB_Spec] 
ADD (DATABASE_ROLE_MEMBER_CHANGE_GROUP);
GO

/* enable db audit spec */
USE AdventureWorks2014;
GO
ALTER DATABASE AUDIT SPECIFICATION [AdventureWorks2014_DB_Spec] 
WITH (STATE = ON);
GO

/* modify serve audit */
USE master;
GO
ALTER SERVER AUDIT [TroisMots_Server_Audit] WITH (STATE = OFF);
ALTER SERVER AUDIT [TroisMots_Server_Audit] TO APPLICATION_LOG;
ALTER SERVER AUDIT [TroisMots_Server_Audit] WITH (STATE = ON);

/* remove db audit spec */
USE AdventureWorks2014;
GO
ALTER DATABASE AUDIT SPECIFICATION [AdventureWorks2014_DB_Spec] WITH (STATE = OFF);
DROP DATABASE AUDIT SPECIFICATION [AdventureWorks2014_DB_Spec];
GO

/* remove server audit spec */
USE master;
GO
ALTER SERVER AUDIT SPECIFICATION [TroisMots_Server_Audit_Spec] WITH (STATE = OFF);
DROP SERVER AUDIT SPECIFICATION [TroisMots_Server_Audit_Spec];
GO

/* remove server audit */
USE master;
GO
ALTER SERVER AUDIT [TroisMots_Server_Audit] WITH (STATE = OFF);
DROP SERVER AUDIT [TroisMots_Server_Audit];
GO
