/* 29-3 */
USE master;
GO
ALTER LOGIN [ROIS\PETITMOT\FredericJeanLouis] DISABLE;
GO

USE master;
GO
ALTER LOGIN [ROIS\PETITMOT\FredericJeanLouis] ENABLE;
GO

USE master;
GO
ALTER LOGIN [ROIS\PETITMOT\DuMondeContenu] 
    WITH DEFAULT_DATABASE = master;
GO
