/* 12-5 */
USE AdventureWorks2014;
GO
ALTER TABLE Person.Address 
    SET ( LOCK_ESCALATION = AUTO );

SELECT lock_escalation,lock_escalation_desc 
FROM sys.tables WHERE name='Address';
GO

/* Disable Lock Escalation */
USE AdventureWorks2014;
GO
ALTER TABLE Person.Address
SET ( LOCK_ESCALATION = DISABLE);

SELECT lock_escalation,lock_escalation_desc 
FROM sys.tables WHERE name='Address';
GO

/*You may want to revert the Lock_Escalation back to the original setting 
after completing this example.
*/