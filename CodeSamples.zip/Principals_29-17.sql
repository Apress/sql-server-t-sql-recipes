/* 29-17 */
/* create a user and then orphan that user */
USE AdventureWorks2014;
GO
If not exists (select name from sys.server_principals
            where name ='Gargouille')
Begin
CREATE LOGIN Gargouille
WITH PASSWORD = 'BigTr3e',
DEFAULT_DATABASE = AdventureWorks2014;
End
GO
If not exists (select name from sys.database_principals
            where name = 'Gargouille')
Begin
CREATE USER Gargouille;
END
DROP LOGIN [GARGOUILLE];
CREATE LOGIN Gargouille
WITH PASSWORD = 'BigTr3e',
DEFAULT_DATABASE = AdventureWorks2014;
GO

USE AdventureWorks2014;
GO
SELECT dp.name AS OrphanUser, dp.sid AS OrphanSid
FROM sys.database_principals dp
LEFT OUTER JOIN sys.server_principals sp 
    ON dp.sid = sp.sid 
WHERE sp.sid IS NULL 
    AND dp.type_desc = 'SQL_USER' 
    AND dp.principal_id > 4;
GO


/*remap login and user */
USE AdventureWorks2014;
GO
ALTER USER Gargouille WITH LOGIN = Gargouille;
GO

USE TestDB;
GO
ALTER USER [FeeDauphin]
WITH LOGIN = [PETITMOT\FeeDauphin];
GO
