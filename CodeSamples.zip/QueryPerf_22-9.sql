/* 22-9 */
USE AdventureWorks2014;
GO 
EXECUTE sp_executesql N'SELECT TransactionID, ProductID, TransactionType, Quantity FROM   Production.TransactionHistoryArchive WHERE   ProductID = @ProductID AND
TransactionType = @TransactionType AND Quantity > @Quantity', N'@ProductID int, @TransactionType char(1), @Quantity int', @ProductID =813, @TransactionType = 'S', @Quantity = 5
