/* 12-8 */

USE AdventureWorks2014;
GO
BEGIN TRAN
UPDATE Production.ProductInventory 
SET Quantity = 400 
WHERE ProductID = 1 AND LocationID = 1;

/*In a second query window, this example demonstrates
 setting up a lock timeout period of one second (1,000 milliseconds).
 */

USE AdventureWorks2014;
GO
SET LOCK_TIMEOUT 1000;
UPDATE Production.ProductInventory 
SET Quantity = 406 
WHERE ProductID = 1 AND LocationID = 1;

/* From the original query window */
ROLLBACK TRANSACTION;