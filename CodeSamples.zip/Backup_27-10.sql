/* 27-10 */
USE master;
GO

BACKUP DATABASE AdventureWorks2014
TO DISK =  'C:\Apress\AdventureWorks2014.bak'
MIRROR TO DISK = 'C:\Apress\MirroredBackup\AdventureWorks2014.bak'
WITH
   FORMAT,
   MEDIANAME = 'AdventureWorksSet1';
GO
