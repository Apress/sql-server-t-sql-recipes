/* 20-2 */
USE AdventureWorks2014;
GO

-- Create Department "Approval" table 
CREATE TABLE HumanResources.DepartmentApproval
       (
        Name NVARCHAR(50) NOT NULL
                          UNIQUE,
        GroupName NVARCHAR(50) NOT NULL,
        ModifiedDate DATETIME NOT NULL
                              DEFAULT GETDATE()
       ) ;
GO
-- Create view to see both approved and pending approval departments
CREATE VIEW HumanResources.vw_Department
AS
       SELECT   Name,
                GroupName,
                ModifiedDate,
                'Approved' Status
       FROM     HumanResources.Department
       UNION
       SELECT   Name,
                GroupName,
                ModifiedDate,
                'Pending Approval' Status
       FROM     HumanResources.DepartmentApproval ;
GO

-- Create an INSTEAD OF trigger on the new view
CREATE TRIGGER HumanResources.trg_vw_Department ON HumanResources.vw_Department
       INSTEAD OF INSERT
AS
       SET NOCOUNT ON
       INSERT INTO HumanResources.DepartmentApproval
                (Name,
                 GroupName)
                SELECT  i.Name,
                        i.GroupName
                FROM    inserted i
                WHERE   i.Name NOT IN (
                        SELECT  Name
                        FROM    HumanResources.DepartmentApproval) ;
GO

-- Insert into the new view, even though view is a UNION
-- of two different tables
INSERT INTO HumanResources.vw_Department
        (Name,
         GroupName)
VALUES  ('Print Production',
         'Manufacturing') ;

-- Check the view's contents 
SELECT  Status,
        Name
FROM    HumanResources.vw_Department
WHERE   GroupName = 'Manufacturing' ;
