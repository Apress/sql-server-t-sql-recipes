/* 24-1 */
USE AdventureWorks2014;
GO
SELECT OBJECT_NAME(object_id) ObjectName,
index_id,
index_type_desc,
avg_fragmentation_in_percent 
FROM sys.dm_db_index_physical_stats (DB_ID('AdventureWorks2014'),NULL, NULL, NULL, 'LIMITED') 
WHERE avg_fragmentation_in_percent > 30 
ORDER BY OBJECT_NAME(object_id);

/* example 2 */
USE AdventureWorks2014;
GO
SELECT OBJECT_NAME(f.object_id) ObjectName,
        i.name IndexName,
        f.index_type_desc,
        f.avg_fragmentation_in_percent
FROM sys.dm_db_index_physical_stats
        (DB_ID('AdventureWorks2014'), OBJECT_ID('Production.ProductDescription'), 2, NULL, 'LIMITED')  f
INNER JOIN sys.indexes i 
        ON i.object_id = f.object_id 
        AND i.index_id = f.index_id;
