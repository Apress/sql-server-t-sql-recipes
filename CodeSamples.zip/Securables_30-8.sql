/* 30-8 */
/* grant permissions */

USE AdventureWorks2014;
GO
GRANT DELETE, INSERT, SELECT, UPDATE ON HumanResources.Department TO TestUser;
GO

/* grant permissions to role */
USE AdventureWorks2014;
GO
CREATE ROLE ReportViewers
GRANT EXECUTE, VIEW DEFINITION ON dbo.uspGetManagerEmployees TO ReportViewers;
GO

/* deny permissions */
USE AdventureWorks2014;
GO
DENY ALTER ON HumanResources.Department TO TestUser;
GO

/* revoke permissions */
USE AdventureWorks2014;
GO
REVOKE INSERT, UPDATE, DELETE ON HumanResources.Department TO TestUser;
GO
