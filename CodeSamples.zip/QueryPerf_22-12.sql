/* 22-12 */
USE AdventureWorks2014;
GO
SELECT
p.Title,
p.FirstName,
p.MiddleName,
p.LastName 
FROM HumanResources.Employee e 
INNER JOIN Person.Person p
ON p.BusinessEntityID = e.BusinessEntityID 
WHERE Title = 'Ms.';
GO

/* get the plan_handle */
USE AdventureWorks2014;
GO
SELECT plan_handle 
FROM sys.dm_exec_query_stats qs 
CROSS APPLY sys.dm_exec_sql_text(plan_handle) t 
WHERE t.text LIKE 'SELECT%p.Title%' 
AND t.text LIKE '%Ms%';

/* Now create the plan guide */
EXEC sp_create_plan_guide_from_handle 'PlanGuide_EmployeeContact', 
@plan_handle = 0x06000800AEC42626F0F03B020100000001000000000000000000000000000000000000000000000000000000, 
@statement_start_offset = NULL;

/* confirm it was created */
USE AdventureWorks2014;
GO
SELECT name, query_text, hints 
FROM sys.plan_guides;

