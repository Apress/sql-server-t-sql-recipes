/* 18-12 */
Use AdventureWorks2014;
GO
CREATE TYPE Department_TT AS TABLE (Name nvarchar(50), GroupName nvarchar(50));
GO
/* Once the new table type is created in the database, I 
can now reference it in module definitions and within the code.
*/

Use AdventureWorks2014;
GO
CREATE PROCEDURE dbo.usp_INS_Department_NewStyle
      @DepartmentTable as Department_TT 
READONLY 
AS

INSERT INTO HumanResources.Department (Name, GroupName)
      SELECT Name, GroupName 
            FROM @DepartmentTable;
GO

/* Testing the TVP */
Use AdventureWorks2014;
GO
/*
-- I can declare our new type for use within a T-SQL batch 
-- Insert multiple rows into this table-type variable
*/

DECLARE @StagingDepartmentTable as Department_TT
INSERT INTO @StagingDepartmentTable(Name, GroupName)
      VALUES ('Archivists', 'Accounting');
INSERT INTO @StagingDepartmentTable(Name, GroupName)
      VALUES ('Public Media', 'Legal');
INSERT @StagingDepartmentTable(Name, GroupName)
      VALUES ('Internal Admin', 'Office Administration');
/*
-- Pass this table-type variable to the procedure in a single call
*/
EXECUTE dbo.usp_INS_Department_NewStyle @StagingDepartmentTable;
GO
