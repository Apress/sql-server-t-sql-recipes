/* 12-10 */
/*Create prior to attempting to cause a deadlock */
CREATE EVENT SESSION [Deadlock] ON SERVER 
ADD EVENT sqlserver.lock_deadlock(
    ACTION(sqlserver.database_name,sqlserver.plan_handle,sqlserver.sql_text)),
ADD EVENT sqlserver.xml_deadlock_report 
ADD TARGET package0.event_file(SET filename=N'C:\Database\XE\Deadlock.xel')
WITH (STARTUP_STATE=ON)
GO

ALTER EVENT SESSION Deadlock
ON SERVER
STATE = START;
GO

/* read the captured data - after attempting a deadlock */

SELECT TargetData AS DeadlockGraph
FROM
(SELECT CAST(event_data AS xml) AS TargetData
            FROM sys.fn_xe_file_target_read_file('C:\Database\XE\Deadlock*.xel',NULL,NULL, NULL) 
			)AS Data
WHERE TargetData.value('(event/@name)[1]', 'varchar(50)') = 'xml_deadlock_report';

/* from a second query window */
USE AdventureWorks2014;
GO
SET NOCOUNT ON;
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE;
WHILE 1=1 
BEGIN 
BEGIN TRAN
UPDATE Purchasing.Vendor
SET CreditRating = 1
WHERE BusinessEntityID = 1494;
UPDATE Purchasing.Vendor
SET CreditRating = 2
WHERE BusinessEntityID = 1492;
COMMIT TRAN 
END

/* In a third query window, the following query is executed. */
USE AdventureWorks2014;
GO
SET NOCOUNT ON;
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE;
WHILE 1=1 
BEGIN 
BEGIN TRAN
UPDATE Purchasing.Vendor
SET CreditRating = 2
WHERE BusinessEntityID = 1492;
UPDATE Purchasing.Vendor
SET CreditRating = 1
WHERE BusinessEntityID = 1494;
COMMIT TRAN 
END


/* cleanup from second query window */
ROLLBACK TRANSACTION;