/* 15-13 */

USE AdventureWorks2014;
GO
DROP INDEX NI_TerminationReason_TerminationReason_DepartmentID
ON HumanResources.TerminationReason;
GO
CREATE NONCLUSTERED INDEX NI_TerminationReason_TerminationReason_DepartmentID 
  ON HumanResources.TerminationReason (TerminationReason ASC, DepartmentID ASC) 
  WITH (PAD_INDEX=ON, FILLFACTOR=70);
GO
