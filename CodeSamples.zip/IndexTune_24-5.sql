/* 24-5 */
USE AdventureWorks2014;
GO
SELECT *
FROM Sales.Customer;

USE AdventureWorks2014;
GO
SELECT AccountNumber 
FROM Sales.Customer 
WHERE TerritoryID = 4;


/* query the stats */
USE AdventureWorks2014;
GO
SELECT i.name IndexName, user_seeks, user_scans, last_user_seek, last_user_scan 
FROM sys.dm_db_index_usage_stats s 
INNER JOIN sys.indexes i 
ON s.object_id = i.object_id 
AND s.index_id = i.index_id 
WHERE database_id = DB_ID('AdventureWorks2014') 
AND s.object_id = OBJECT_ID('Sales.Customer');
