/* 29-8 */
USE master;
GO
ALTER LOGIN PipoGaston
WITH PASSWORD = 'Chuch0t3r'
OLD_PASSWORD = ' Tr0isM0ts';
GO

USE master;
GO
ALTER LOGIN Gaston
WITH DEFAULT_DATABASE = [AdventureWorks2014];
GO

USE master;
GO
ALTER LOGIN Gaston
WITH NAME = HyBrasil, PASSWORD = 'UC@ntCMe';
GO
