/* 30-3 */
USE master;
GO
CREATE LOGIN TestUser2
WITH PASSWORD = 'abcdelllllll!';
GO

/* assign some permissions */
USE master;
GO
DENY SHUTDOWN TO TestUser2;
GRANT CREATE ANY DATABASE TO TestUser2;
GO

/* view the assigned permissions */
USE master;
GO
SELECT p.class_desc, p.permission_name, p.state_desc 
    FROM sys.server_permissions p 
    INNER JOIN sys.server_principals s 
        ON p.grantee_principal_id = s.principal_id 
    WHERE s.name = 'TestUser2';
GO
